<?php
session_start();

include "config.php";

// Initialize variables
$error = '';
$success = '';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $name = trim($_POST['name']);
    $username = trim($_POST['username']);
    $email = trim($_POST['email']);
    $password = trim($_POST['password']);

    // Password hashing
    $hashedPassword = md5($password);



    // Check if username or email already exists
    $checkQuery = "SELECT * FROM `user` WHERE `username` = ? OR `email` = ?";
    $stmt = $conn->prepare($checkQuery);
    $stmt->bind_param('ss', $username, $email);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        $error = "Username or email already exists. Please try again.";
    } else {
        // Insert new user
        $insertQuery = "INSERT INTO `user` (`name`, `username`, `email`, `password`) VALUES (?, ?, ?, ?)";
        $stmt = $conn->prepare($insertQuery);
        $stmt->bind_param('ssss', $name, $username, $email, $hashedPassword);

        if ($stmt->execute()) {
            $success = "Registration successful! You can now <a href='login.php'>login</a> but be sure that the admin make your account active first";
        } else {
            $error = "Error occurred during registration. Please try again.";
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Register - CryptZone</title>
    <link rel="stylesheet" href="styles.css">
    <link rel="icon" href="images/logo.png">
</head>
<body>
    <div class="login-container">
        <div class="form-wrapper">
            <h1 class="form-title">Register for CryptZone</h1>
            <?php if ($error): ?>
                <p class="error"><?php echo $error; ?></p>
            <?php endif; ?>
            <?php if ($success): ?>
                <p class="success"><?php echo $success; ?></p>
            <?php endif; ?>
            <form action="register.php" method="POST">
                <div class="input-field">
                    <input type="text" name="name" id="name" required placeholder=" ">
                    <label for="name">Full Name</label>
                </div>
                <div class="input-field">
                    <input type="text" name="username" id="username" required placeholder=" ">
                    <label for="username">Username</label>
                </div>
                <div class="input-field">
                    <input type="email" name="email" id="email" required placeholder=" ">
                    <label for="email">Email</label>
                </div>
                <div class="input-field">
                    <input type="password" name="password" id="password" required placeholder=" ">
                    <label for="password">Password</label>
                </div>

                <button type="submit" class="btn">Register</button>
            </form>
            <p class="register-link">Already have an account? <a href="login.php">Login here</a>.</p>
        </div>
    </div>
</body>
</html>
