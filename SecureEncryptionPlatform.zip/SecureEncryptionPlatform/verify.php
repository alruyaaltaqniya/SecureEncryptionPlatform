<?php
session_start();
include "config.php";

if (!isset($_SESSION['tempUserId']) || !isset($_SESSION['verificationCode'])) {
    header('Location: login.php');
    exit();
}

$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $enteredCode = $_POST['verificationCode'];

    if ($enteredCode == $_SESSION['verificationCode']) {
        $userId = $_SESSION['tempUserId'];
        $userType = $_SESSION['userType'];

        // Complete login
        $_SESSION['userId'] = $userId;
        unset($_SESSION['tempUserId'], $_SESSION['verificationCode']);

        if ($userType === 'user') {
            // Insert into activity log
            $insertLog = "INSERT INTO activitylog (userId) VALUES (?)";
            $logStmt = $conn->prepare($insertLog);
            $logStmt->bind_param('i', $userId);
            $logStmt->execute();

            // Update statusOnline to 'online'
            $updateStatus = "UPDATE user SET statusOnline = 'online' WHERE id = ?";
            $statusStmt = $conn->prepare($updateStatus);
            $statusStmt->bind_param('i', $userId);
            $statusStmt->execute();
        }

        // Redirect based on user type
        if ($userType === 'admin') {
            header('Location: admin/');
        } else {
            header('Location: user/');
        }
        exit();
    } else {
        $error = "Invalid verification code.";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Verify - CryptZone</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>
<div class="login-container">
    <div class="form-wrapper">
        <h1 class="form-title">Two-Factor Authentication</h1>
        <?php if ($error): ?>
            <p class="error"><?php echo $error; ?></p>
        <?php endif; ?>
        <form action="verify.php" method="POST">
            <div class="input-field">
                <input type="text" name="verificationCode" id="verificationCode" required placeholder=" ">
                <label for="verificationCode">Enter Verification Code</label>
            </div>
            <button type="submit" class="btn">Verify</button>
        </form>
    </div>
</div>
</body>
</html>
