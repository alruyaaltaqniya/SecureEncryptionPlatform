<?php
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\SMTP;
use PHPMailer\PHPMailer\Exception;

//Load Composer's autoloader
require 'mailer/autoload.php';
ob_start(); // Start output buffering
session_start();
include "config.php";

$error = '';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $username = trim($_POST['username']);
    $password = trim(md5($_POST['password']));
    $userType = $_POST['userType']; // 'admin' or 'user'

    $table = ($userType == 'admin') ? 'admin' : 'user';

    $sql = "SELECT * FROM `$table` WHERE `username` = ? AND `password` = ? AND `status` = 'active'";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param('ss', $username, $password);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows === 1) {
        $user = $result->fetch_assoc();
        $_SESSION['tempUserId'] = $user['id'];
        $_SESSION['userType'] = $userType;
        $_SESSION['username'] = $user['username'];

        // Generate a random 6-digit verification code
        $verificationCode = rand(100000, 999999);
        $_SESSION['verificationCode'] = $verificationCode;

        $mail = new PHPMailer(true);
        try {
          $mail = new PHPMailer();

          //Server settings
            $mail->SMTPDebug = SMTP::DEBUG_SERVER;                      //Enable verbose debug output
            $mail->isSMTP();                                            //Send using SMTP
            $mail->Host       = 'smtp.gmail.com';                     //Set the SMTP server to send through
            $mail->SMTPAuth   = true;                                   //Enable SMTP authentication
          $mail->Username   = 'emaal7739@gmail.com';                     //SMTP username
          $mail->Password   = 'kylbjhalbyylnmbd';                               //SMTP password

            $mail->SMTPSecure = 'ssl';
            $mail->Port       = 465;

             $mail->isHTML(true);
              $mail->CharSet="UTF-8";

            $mail->setFrom('emaal7739@gmail.com', 'CryptZone');
            $mail->addAddress($user['email']);

            $mail->isHTML(true);
            $mail->Subject = 'Your CryptZone Verification Code';
            $mail->Body = "
                <html>
                <head>
                    <style>
                        body { font-family: Arial, sans-serif; }
                        .container { text-align: center; margin: 20px auto; padding: 20px; background: #f4f4f4; border-radius: 8px; width: 90%; max-width: 600px; }
                        .code { font-size: 24px; font-weight: bold; color: #333; }
                        .footer { margin-top: 20px; font-size: 12px; color: #555; }
                    </style>
                </head>
                <body>
                    <div class='container'>
                        <h2>Two-Factor Authentication</h2>
                        <p>Your verification code is:</p>
                        <div class='code'>$verificationCode</div>
                        <p>Please use this code to complete your login.</p>
                        <div class='footer'>&copy; " . date('Y') . " CryptZone</div>
                    </div>
                </body>
                </html>
            ";

            $mail->send();
            header('Location: verify.php');
            exit;
        } catch (Exception $e) {
            $error = "Failed to send verification code. Please try again.";
        }
    } else {
        $error = "Invalid username or password.";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login - CryptZone</title>
    <link rel="stylesheet" href="styles.css">
    <link rel="icon" href="images/logo.png">
</head>
<body>
<div class="login-container">
    <div class="form-wrapper">
        <h1 class="form-title">CryptZone Login</h1>
        <?php if ($error): ?>
            <p class="error"><?php echo $error; ?></p>
        <?php endif; ?>
        <form action="login.php" method="POST">
            <div class="input-field">
                <input type="text" name="username" id="username" required placeholder=" ">
                <label for="username">Username</label>
            </div>
            <div class="input-field">
                <input type="password" name="password" id="password" required placeholder=" ">
                <label for="password">Password</label>
            </div>
            <div class="input-field select-field">
                <select name="userType" id="userType" required>
                    <option value="" disabled selected>Login as</option>
                    <option value="user">User</option>
                    <option value="admin">Admin</option>
                </select>
            </div>
            <button type="submit" class="btn">Login</button>
        </form>
        <p class="register-link">Don't have an account? <a href="register.php">Register now</a>.</p>
    </div>
</div>
</body>
</html>
