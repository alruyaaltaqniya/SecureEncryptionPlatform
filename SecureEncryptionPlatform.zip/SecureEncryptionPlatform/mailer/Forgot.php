<?php

session_start();
require_once 'mail.php';
include("includes/db.php");

?>
<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title></title>
    <link rel="stylesheet" href="a.css">
  </head>
  <body>
    <br>
  <br>
    <form class="form-login" action="" method="post" >
      <div class="cont">
          <div class="form sign-in">
              <h2>Forgot Page </h2>
              <label>
                  <span>ID</span>
                  <input type="number" name="text1" />
              </label>
              <label>
                  <span>Email</span>
                  <input type="email" name="text2"/>
              </label>
              <button type="submit" class="submit" name="admin_login">Send</button>

          </div>
          <div class="sub-cont">
              <div class="img">



              </div>


              </div>
          </div>
  </form>

      <script>
          document.querySelector('.img__btn').addEventListener('click', function() {
              document.querySelector('.cont').classList.toggle('s--signup');
          });
      </script>
  </body>
</html>
<?php

if(isset($_POST['admin_login'])){

$admin_email = mysqli_real_escape_string($con,$_POST['text1']);

$admin_pass = mysqli_real_escape_string($con,$_POST['text2']);

$get_admin = "select * from jazansiteforacademics where id ='$admin_email'";

$result = mysqli_query($con, $get_admin);
      $row = mysqli_fetch_array($result, MYSQLI_ASSOC);
      $count = mysqli_num_rows($result);
      if($result = mysqli_query($con, $get_admin)){
    if(mysqli_num_rows($result) > 0){
      while($row = mysqli_fetch_array($result)){



$bb=$row['id'];
$as=$row['Password'];
$mail->setFrom('emaal7739@gmail.com', 'Forgot password');
$mail->addAddress($admin_pass);
$mail->Subject = " Forgot password";
$mail->Body    = "<h1>ID $bb  <br>password is $as </h1>";
if($mail->send()){
$message = "go in your email";
echo "<script type='text/javascript'>alert('$message');</script>";
echo  "<script>
  window.location = 'a.php';
</script>";
}
else {
$message = "error";
echo "<script type='text/javascript'>alert('$message');</script>";
echo  "<script>
  window.location = 'a.php';
  </script>";
}


}

}

}

else{
$message = "this is not your id";

echo "<script type='text/javascript'>alert('$message');</script>";
}
}

?>
