<?php include "header.php" ?>


    <!-- Header -->
    <header id="header" class="ex-header">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <h1>Terms & Conditions</h1>
                </div> <!-- end of col -->
            </div> <!-- end of row -->
        </div> <!-- end of container -->
    </header> <!-- end of ex-header -->
    <!-- end of header -->


    <!-- Breadcrumbs -->
    <div class="ex-basic-1">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <div class="breadcrumbs">
                        <a href="index.html">Home</a><i class="fa fa-angle-double-right"></i><span>Terms & Conditions</span>
                    </div> <!-- end of breadcrumbs -->
                </div> <!-- end of col -->
            </div> <!-- end of row -->
        </div> <!-- end of container -->
    </div> <!-- end of ex-basic-1 -->
    <!-- end of breadcrumbs -->


    <!-- Terms Content -->
    <div class="ex-basic-2">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <div class="text-container dark">
                      <h3>Limitations Of Liability</h3>
                <p>CryptZone may collect and process certain information from your device, including activities performed on our platform, the type of hardware and software used (e.g., operating system, browser), and information from cookies. For instance, we may automatically collect your IP address, browser and device type, access times, the page from which you navigated, and the pages accessed on our platform.</p>
                <p>When you register for a CryptZone account or use the platform, we may collect some <a href="#your-link">Personal Information</a>, such as:</p>

                <ul class="list-unstyled li-space-lg">
    <li class="media">
        <i class="fas fa-square"></i>
        <div class="media-body">The geographic location where you access CryptZone should align with the region specified during your account registration.</div>
    </li>
    <li class="media">
        <i class="fas fa-square"></i>
        <div class="media-body">Your full name, username, email address, and contact details must be provided accurately in the registration form.</div>
    </li>
    <li class="media">
        <i class="fas fa-square"></i>
        <div class="media-body">A unique CryptZone user ID (an alphanumeric string) is assigned to you upon registration for secure identification.</div>
    </li>
    <li class="media">
        <i class="fas fa-square"></i>
        <div class="media-body">Additional profile information is optional and not required for basic account functionality.</div>
    </li>
    <li class="media">
        <i class="fas fa-square"></i>
        <div class="media-body">Your IP address and, when applicable, timestamp details for consent confirmation are required for compliance.</div>
    </li>
    <li class="media">
        <i class="fas fa-square"></i>
        <div class="media-body">Information submitted by you or your organization through various channels is securely processed and managed.</div>
    </li>
</ul>

                    </div> <!-- end of text-container -->

                    <div class="text-container">
                    <h3>Terms And Conditions</h3>
                    <p>Under no circumstances shall CryptZone be liable for any direct, indirect, special, incidental, or consequential damages, including, but not limited to, loss of data or profit, arising out of the use or inability to use the platform, even if CryptZone or an authorized representative has been advised of the possibility of such damages. If your use of the platform results in the need for servicing, repair, or correction of equipment or data, you assume any associated costs as the user of the application.</p>
                </div> <!-- end of text-container -->

                <div class="text-container">
        <h3>License Types & Platform Usage</h3>
        <p>CryptZone adheres to a strict licensing policy to ensure the security and privacy of its users. All encryption and decryption functionalities are provided under the CryptZone Personal Use License. You may not offer, modified or unmodified, any part of the platform for redistribution or resale of any kind. Usage of the platform is strictly limited to secure communication and data management purposes within your community.</p>
        <p>Our services empower users to protect their sensitive information, collaborate securely, and monitor activities, with performance analysis tools to optimize their security practices.</p>
    </div> <!-- end of text-container -->


    <div class="text-container">
<h3>Platform Membership And How It Applies</h3>
<p>By using the CryptZone platform, or submitting any personal information via the platform, you consent to the collection, transfer, storage, and use of your personal information in accordance with our Privacy Policy. If you do not consent to these terms, please refrain from using the platform and its services. CryptZone prioritizes the security and privacy of all user data to ensure a safe communication environment.</p>
</div> <!-- end of text-container -->

<div class="text-container last">
<h3>Assets Used In The Live Preview Content</h3>
<p>CryptZone uses advanced tracking technology on the platform, including unique user identifiers, to help us recognize you across different services, monitor usage, and optimize platform performance. By using CryptZone, you agree to the use of cookies and other tracking technologies in your browser to enhance security and improve your user experience. Cookies are small text files placed on your device when you visit a website, enabling secure and seamless interactions.</p>
<a class="btn-solid-reg" href="index.PHP">BACK</a>
</div> <!-- end of text-container -->

                </div>
            </div> <!-- end of row -->
        </div> <!-- end of container -->
    </div> <!-- end of ex-basic -->
    <!-- end of terms content -->


    <!-- Breadcrumbs -->
    <div class="ex-basic-1">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <div class="breadcrumbs">
                        <a href="index.PHP">Home</a><i class="fa fa-angle-double-right"></i><span>Terms & Conditions</span>
                    </div> <!-- end of breadcrumbs -->
                </div> <!-- end of col -->
            </div> <!-- end of row -->
        </div> <!-- end of container -->
    </div> <!-- end of ex-basic-1 -->
    <!-- end of breadcrumbs -->


<?php include "footer.php" ?>
