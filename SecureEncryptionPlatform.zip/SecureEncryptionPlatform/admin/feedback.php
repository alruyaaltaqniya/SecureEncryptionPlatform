<?php
session_start();
include "config.php";

// Check if admin is logged in
if (!isset($_SESSION['userId']) || $_SESSION['userType'] !== 'admin') {
    header("Location: login.php");
    exit();
}

// Fetch feedback
$feedbackQuery = "SELECT f.feedbackId, f.feedbackText, f.feedbackDate, f.state, u.username AS user, u.id AS userId
                  FROM feedback f
                  JOIN user u ON f.userId = u.id
                  ORDER BY f.feedbackDate DESC";
$feedbackResult = $conn->query($feedbackQuery);

// Handle feedback actions
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {
    $action = $_POST['action'];

    if ($action === 'updateState' && isset($_POST['feedbackId'], $_POST['state'])) {
        $feedbackId = intval($_POST['feedbackId']);
        $state = $_POST['state'];

        $updateQuery = "UPDATE feedback SET state = ? WHERE feedbackId = ?";
        $stmt = $conn->prepare($updateQuery);
        $stmt->bind_param('si', $state, $feedbackId);

        if ($stmt->execute()) {
            $success = "Feedback state updated successfully.";
        } else {
            $error = "Failed to update feedback state.";
        }
    }

    if ($action === 'deleteFeedback' && isset($_POST['feedbackId'])) {
        $feedbackId = intval($_POST['feedbackId']);

        $deleteQuery = "DELETE FROM feedback WHERE feedbackId = ?";
        $stmt = $conn->prepare($deleteQuery);
        $stmt->bind_param('i', $feedbackId);

        if ($stmt->execute()) {
            $success = "Feedback deleted successfully.";
        } else {
            $error = "Failed to delete feedback.";
        }
    }

    if ($action === 'sendMessage' && isset($_POST['userId'], $_POST['messageText'])) {
        $userId = intval($_POST['userId']);
        $messageText = trim($_POST['messageText']);

        $saveMessageQuery = "INSERT INTO feedback (userId, feedbackText, state) VALUES (?, ?, 'read')";
        $stmt = $conn->prepare($saveMessageQuery);
        $stmt->bind_param('is', $userId, $messageText);

        if ($stmt->execute()) {
            $success = "Message sent successfully and saved as feedback.";
        } else {
            $error = "Failed to save message as feedback.";
        }
    }

}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.datatables.net/1.13.4/css/dataTables.bootstrap5.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css" rel="stylesheet">
    <link rel="stylesheet" href="styles.css">
    <title>Feedback Management</title>
</head>
<body>
<?php include "header.php"; ?>
    <main class="main-content">
<div class="container mt-4">
    <h1 class="text-center">Feedback Management</h1>

    <?php if (isset($success)): ?>
        <div class="alert alert-success"><?php echo $success; ?></div>
    <?php elseif (isset($error)): ?>
        <div class="alert alert-danger"><?php echo $error; ?></div>
    <?php endif; ?>

    <div class="card mt-4">
        <div class="card-header">
            <h2>User Feedback</h2>
        </div>
        <div class="card-body">
            <table id="userTable" class="table table-striped table-hover">
                <thead>
                    <tr>
                        <th>#</th>
                        <th>User</th>
                        <th>Feedback</th>
                        <th>Date/Time</th>
                        <th>State</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                <?php if ($feedbackResult->num_rows > 0): ?>
                    <?php while ($row = $feedbackResult->fetch_assoc()): ?>
                        <tr>
                            <td><?php echo $row['feedbackId']; ?></td>
                            <td><?php echo htmlspecialchars($row['user']); ?></td>
                            <td><?php echo htmlspecialchars($row['feedbackText']); ?></td>
                            <td><?php echo $row['feedbackDate']; ?></td>
                            <td><?php echo htmlspecialchars($row['state']); ?></td>
                            <td>
                                <form method="POST" class="d-inline">
                                    <input type="hidden" name="feedbackId" value="<?php echo $row['feedbackId']; ?>">
                                    <input type="hidden" name="action" value="updateState">
                                    <select name="state" onchange="this.form.submit()" class="form-select form-select-sm">
                                        <option value="unread" <?php echo $row['state'] === 'unread' ? 'selected' : ''; ?>>Unread</option>
                                        <option value="read" <?php echo $row['state'] === 'read' ? 'selected' : ''; ?>>Read</option>
                                        <option value="resolved" <?php echo $row['state'] === 'resolved' ? 'selected' : ''; ?>>Resolved</option>
                                    </select>
                                </form>

                                <form method="POST" class="d-inline">
                                    <input type="hidden" name="feedbackId" value="<?php echo $row['feedbackId']; ?>">
                                    <input type="hidden" name="action" value="deleteFeedback">
                                    <button type="submit" class="btn btn-danger btn-sm">Delete</button>
                                </form>

                                <button class="btn btn-primary btn-sm" onclick="showMessageForm(<?php echo $row['userId']; ?>)">Send Message</button>
                            </td>
                        </tr>
                    <?php endwhile; ?>
                <?php else: ?>
                    <tr>
                        <td colspan="6" class="text-center">No feedback found.</td>
                    </tr>
                <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<div id="messageModal" class="modal">
    <div class="modal-content">
        <span class="close" onclick="hideMessageForm()">&times;</span>
        <h2>Send Message</h2>
        <form method="POST">
            <input type="hidden" name="action" value="sendMessage">
            <input type="hidden" id="modalUserId" name="userId">
            <div class="form-group">
                <label for="messageText">Message</label>
                <textarea id="messageText" name="messageText" class="form-control" required></textarea>
            </div>
            <button type="submit" class="btn btn-primary">Send</button>
        </form>
    </div>
</div>
  </main>
<script src="https://code.jquery.com/jquery-3.6.4.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/js/bootstrap.bundle.min.js"></script>
<script src="https://cdn.datatables.net/1.13.4/js/jquery.dataTables.min.js"></script>
<script src="https://cdn.datatables.net/1.13.4/js/dataTables.bootstrap5.min.js"></script>
<script>
$(document).ready(function() {
    $('#userTable').DataTable();
});
function showMessageForm(userId) {
    document.getElementById('modalUserId').value = userId;
    document.getElementById('messageModal').style.display = 'block';
}
function hideMessageForm() {
    document.getElementById('messageModal').style.display = 'none';
}
</script>

</body>
</html>
