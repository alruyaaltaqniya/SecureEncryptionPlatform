<?php
include 'config.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = mysqli_real_escape_string($conn, $_POST['name']);
    $username = mysqli_real_escape_string($conn, $_POST['username']);
    $email = mysqli_real_escape_string($conn, $_POST['email']);
    $password = md5($_POST['password']);

    $checkUserQuery = "SELECT * FROM user WHERE username='$username' OR email='$email'";
    $result = mysqli_query($conn, $checkUserQuery);

    if (mysqli_num_rows($result) > 0) {
        echo "<script>alert('Username or email already exists!'); window.location.href='usermanagement.php';</script>";
    } else {
        $query = "INSERT INTO user (name, username, email, password, status) VALUES ('$name', '$username', '$email', '$password', 'unactive')";
        if (mysqli_query($conn, $query)) {
            echo "<script>alert('User added successfully!'); window.location.href='usermanagement.php';</script>";
        } else {
            echo "<script>alert('Error adding user!'); window.location.href='usermanagement.php';</script>";
        }
    }
}
?>
