<?php
include 'config.php';

if (isset($_GET['id'])) {
    $id = intval($_GET['id']);

    $query = "DELETE FROM user WHERE id=$id";
    if (mysqli_query($conn, $query)) {
        echo "<script>alert('User deleted successfully!'); window.location.href='usermanagement.php';</script>";
    } else {
        echo "<script>alert('Error deleting user!'); window.location.href='usermanagement.php';</script>";
    }
}
?>
