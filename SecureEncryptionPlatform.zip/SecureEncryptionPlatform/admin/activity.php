<?php
session_start();
include "config.php";

// Check if admin is logged in
if (!isset($_SESSION['userId']) || $_SESSION['userType'] !== 'admin') {
    header("Location: login.php");
    exit();
}

// Fetch all activity logs
$activityQuery = "SELECT a.id, a.dateTime, u.username FROM activitylog a
                  LEFT JOIN user u ON a.userId = u.id
                  ORDER BY a.dateTime DESC";
$activityResult = $conn->query($activityQuery);

// Handle delete action
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['deleteId'])) {
    $deleteId = intval($_POST['deleteId']);
    $deleteQuery = "DELETE FROM activitylog WHERE id = ?";
    $stmt = $conn->prepare($deleteQuery);
    $stmt->bind_param('i', $deleteId);
    if ($stmt->execute()) {
        $success = "Activity log deleted successfully.";
    } else {
        $error = "Failed to delete activity log.";
    }
}

// Fetch data for the chart
$chartQuery = "SELECT u.username, COUNT(a.id) AS activityCount
               FROM activitylog a
               JOIN user u ON a.userId = u.id
               GROUP BY a.userId";
$chartResult = $conn->query($chartQuery);

$chartData = [];
while ($row = $chartResult->fetch_assoc()) {
    $chartData[] = [
        'username' => $row['username'],
        'activityCount' => (int)$row['activityCount']
    ];
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Activity Log</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <link href="https://cdn.datatables.net/1.13.4/css/dataTables.bootstrap5.min.css" rel="stylesheet">
</head>
<body>
<?php include "header.php"; ?>
    <main class="main-content">
<div class="container mt-4">
    <h1 class="text-center">Activity Log</h1>

    <?php if (isset($success)): ?>
        <div class="alert alert-success"><?php echo $success; ?></div>
    <?php elseif (isset($error)): ?>
        <div class="alert alert-danger"><?php echo $error; ?></div>
    <?php endif; ?>

    <div class="card mt-4">
        <div class="card-header">
            <h2>User Activity</h2>
        </div>
        <div class="card-body">
            <canvas id="activityChart" height="100"></canvas>
        </div>
    </div>

    <div class="card mt-4">
        <div class="card-header">
            <h2>Activity Details</h2>
        </div>
        <div class="card-body">
            <table id="activityTable" class="table table-striped table-hover">
                <thead>
                    <tr>
                        <th>#</th>
                        <th>User</th>
                        <th>Date/Time</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                <?php if ($activityResult->num_rows > 0): ?>
                    <?php while ($row = $activityResult->fetch_assoc()): ?>
                        <tr>
                            <td><?php echo $row['id']; ?></td>
                            <td><?php echo htmlspecialchars($row['username'] ?? 'Unknown'); ?></td>
                            <td><?php echo $row['dateTime']; ?></td>
                            <td>
                                <form method="POST" class="d-inline">
                                    <input type="hidden" name="deleteId" value="<?php echo $row['id']; ?>">
                                    <button type="submit" class="btn btn-danger btn-sm">Delete</button>
                                </form>
                            </td>
                        </tr>
                    <?php endwhile; ?>
                <?php else: ?>
                    <tr>
                        <td colspan="4" class="text-center">No activity logs found.</td>
                    </tr>
                <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
  </main>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/js/bootstrap.bundle.min.js"></script>
<script src="https://cdn.datatables.net/1.13.4/js/jquery.dataTables.min.js"></script>
<script src="https://cdn.datatables.net/1.13.4/js/dataTables.bootstrap5.min.js"></script>
<script src="https://code.jquery.com/jquery-3.6.4.min.js"></script>
<script>
    $(document).ready(function() {
        $('#activityTable').DataTable();
    });

    const chartData = <?php echo json_encode($chartData); ?>;

    const ctx = document.getElementById('activityChart').getContext('2d');
    const activityChart = new Chart(ctx, {
        type: 'bar',
        data: {
            labels: chartData.map(data => data.username),
            datasets: [{
                label: 'Activity Count',
                data: chartData.map(data => data.activityCount),
                backgroundColor: 'rgba(54, 162, 235, 0.6)',
                borderColor: 'rgba(54, 162, 235, 1)',
                borderWidth: 1
            }]
        },
        options: {
            scales: {
                y: {
                    beginAtZero: true
                }
            }
        }
    });
</script>
</body>
</html>
