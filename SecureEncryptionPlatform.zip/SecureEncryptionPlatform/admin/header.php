<?php
include 'config.php';


if (!isset($_SESSION['userId']) || $_SESSION['userType'] !== 'admin') {
    header("Location: login.php");
    exit();
}

$adminName = $_SESSION['username'];
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard - CryptZone</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <link rel="stylesheet" href="style.css">
    <link rel="icon" href="../images/logo.png">
    <link href="../css/styles.css" rel="stylesheet">
</head>
<body>
    <div class="dashboard-container">
        <!-- Sidebar -->
        <aside class="sidebar">
            <div class="sidebar-header">
                <img src="../images/logo.png" alt="CryptZone Logo" class="logo">
                <h2>CryptZone</h2>
            </div>
            <ul class="sidebar-menu">
                <?php
                // Get the current script name
                $current_page = basename($_SERVER['PHP_SELF']);
                ?>
                <li><a href="index.php" class="<?php echo $current_page == 'index.php' ? 'active' : ''; ?>"><i class="fas fa-tachometer-alt"></i> Dashboard</a></li>
                <li><a href="usermanagement.php" class="<?php echo $current_page == 'usermanagement.php' ? 'active' : ''; ?>"><i class="fas fa-users"></i> User Management</a></li>
            <li><a href="logs.php" class="<?php echo $current_page == 'logs.php' ? 'active' : ''; ?>"><i class="fas fa-file-alt"></i> Monitor User </a></li>
              <li><a href="feedback.php" class="<?php echo $current_page == 'feedback.php' ? 'active' : ''; ?>"><i class="fas fa-comments"></i> Feedback</a></li>
                <li><a href="activity.php" class="<?php echo $current_page == 'activity.php' ? 'active' : ''; ?>"><i class="fas fa-chart-line"></i> Activity</a></li>
                <li><a href="profile.php" class="<?php echo $current_page == 'profile.php' ? 'active' : ''; ?>"><i class="fas fa-user"></i> Profile</a></li>
                <li><a href="logout.php" class="<?php echo $current_page == 'logout.php' ? 'active' : ''; ?>"><i class="fas fa-sign-out-alt"></i> Logout</a></li>
            </ul>
        </aside>
