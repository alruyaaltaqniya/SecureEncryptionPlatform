<?php
include 'config.php';

if (isset($_GET['id'])) {
    $id = intval($_GET['id']);

    $query = "UPDATE user SET status='active' WHERE id=$id";
    if (mysqli_query($conn, $query)) {
        echo "<script>alert('User activated successfully!'); window.location.href='usermanagement.php';</script>";
    } else {
        echo "<script>alert('Error activating user!'); window.location.href='usermanagement.php';</script>";
    }
}
?>
