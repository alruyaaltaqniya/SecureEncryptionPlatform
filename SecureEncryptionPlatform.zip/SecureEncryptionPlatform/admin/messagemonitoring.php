<?php
session_start();

// Check if admin is logged in
if (!isset($_SESSION['userType']) || $_SESSION['userType'] !== 'admin') {
    header('Location: login.php');
    exit;
}

include "config.php";

// Fetch logs
$activityLogsQuery = "SELECT al.dateTime, u.username FROM activitylog al JOIN user u ON al.userId = u.id ORDER BY al.dateTime DESC";
$activityLogs = $conn->query($activityLogsQuery);

$encryptionLogsQuery = "SELECT e.dateTime, u.username, e.text, e.encryptiontype FROM encrypt e JOIN user u ON e.userId = u.id ORDER BY e.dateTime DESC";
$encryptionLogs = $conn->query($encryptionLogsQuery);

decryptionLogsQuery = "SELECT d.dateTime, u.username, d.text, d.decrptionType FROM decrypt d JOIN user u ON d.userId = u.id ORDER BY d.dateTime DESC";
$decryptionLogs = $conn->query($decryptionLogsQuery);

$feedbackLogsQuery = "SELECT f.feedbackDate, u.username, f.feedbackText, f.state FROM feedback f JOIN user u ON f.userId = u.id ORDER BY f.feedbackDate DESC";
$feedbackLogs = $conn->query($feedbackLogsQuery);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Logs - Admin Panel</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
<div class="container mt-5">
    <h1 class="mb-4">Logs</h1>

    <ul class="nav nav-tabs" id="logsTabs" role="tablist">
        <li class="nav-item" role="presentation">
            <button class="nav-link active" id="activity-tab" data-bs-toggle="tab" data-bs-target="#activity" type="button" role="tab" aria-controls="activity" aria-selected="true">Activity Logs</button>
        </li>
        <li class="nav-item" role="presentation">
            <button class="nav-link" id="encryption-tab" data-bs-toggle="tab" data-bs-target="#encryption" type="button" role="tab" aria-controls="encryption" aria-selected="false">Encryption Logs</button>
        </li>
        <li class="nav-item" role="presentation">
            <button class="nav-link" id="decryption-tab" data-bs-toggle="tab" data-bs-target="#decryption" type="button" role="tab" aria-controls="decryption" aria-selected="false">Decryption Logs</button>
        </li>
        <li class="nav-item" role="presentation">
            <button class="nav-link" id="feedback-tab" data-bs-toggle="tab" data-bs-target="#feedback" type="button" role="tab" aria-controls="feedback" aria-selected="false">Feedback Logs</button>
        </li>
    </ul>

    <div class="tab-content mt-4" id="logsTabsContent">
        <!-- Activity Logs -->
        <div class="tab-pane fade show active" id="activity" role="tabpanel" aria-labelledby="activity-tab">
            <table class="table table-striped">
                <thead>
                <tr>
                    <th>Date/Time</th>
                    <th>User</th>
                </tr>
                </thead>
                <tbody>
                <?php while ($log = $activityLogs->fetch_assoc()) { ?>
                    <tr>
                        <td><?php echo $log['dateTime']; ?></td>
                        <td><?php echo $log['username']; ?></td>
                    </tr>
                <?php } ?>
                </tbody>
            </table>
        </div>

        <!-- Encryption Logs -->
        <div class="tab-pane fade" id="encryption" role="tabpanel" aria-labelledby="encryption-tab">
            <table class="table table-striped">
                <thead>
                <tr>
                    <th>Date/Time</th>
                    <th>User</th>
                    <th>Encrypted Text</th>
                    <th>Encryption Type</th>
                </tr>
                </thead>
                <tbody>
                <?php while ($log = $encryptionLogs->fetch_assoc()) { ?>
                    <tr>
                        <td><?php echo $log['dateTime']; ?></td>
                        <td><?php echo $log['username']; ?></td>
                        <td><?php echo htmlspecialchars($log['text']); ?></td>
                        <td><?php echo $log['encryptiontype']; ?></td>
                    </tr>
                <?php } ?>
                </tbody>
            </table>
        </div>

        <!-- Decryption Logs -->
        <div class="tab-pane fade" id="decryption" role="tabpanel" aria-labelledby="decryption-tab">
            <table class="table table-striped">
                <thead>
                <tr>
                    <th>Date/Time</th>
                    <th>User</th>
                    <th>Decrypted Text</th>
                    <th>Decryption Type</th>
                </tr>
                </thead>
                <tbody>
                <?php while ($log = $decryptionLogs->fetch_assoc()) { ?>
                    <tr>
                        <td><?php echo $log['dateTime']; ?></td>
                        <td><?php echo $log['username']; ?></td>
                        <td><?php echo htmlspecialchars($log['text']); ?></td>
                        <td><?php echo $log['decrptionType']; ?></td>
                    </tr>
                <?php } ?>
                </tbody>
            </table>
        </div>

        <!-- Feedback Logs -->
        <div class="tab-pane fade" id="feedback" role="tabpanel" aria-labelledby="feedback-tab">
            <table class="table table-striped">
                <thead>
                <tr>
                    <th>Date/Time</th>
                    <th>User</th>
                    <th>Feedback</th>
                    <th>Status</th>
                </tr>
                </thead>
                <tbody>
                <?php while ($log = $feedbackLogs->fetch_assoc()) { ?>
                    <tr>
                        <td><?php echo $log['feedbackDate']; ?></td>
                        <td><?php echo $log['username']; ?></td>
                        <td><?php echo htmlspecialchars($log['feedbackText']); ?></td>
                        <td><?php echo $log['state']; ?></td>
                    </tr>
                <?php } ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
