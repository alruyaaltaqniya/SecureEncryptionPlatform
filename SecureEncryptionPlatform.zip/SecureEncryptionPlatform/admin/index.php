<?php
session_start();
include "header.php"
 ?>

        <!-- Main Content -->
        <main class="main-content">
            <header class="main-header">
                <h1>Welcome, <?php echo $adminName; ?>!</h1>
                <p>Here are your tasks:</p>
            </header>
            <section class="tasks">
                <div class="task-card">
                    <i class="fas fa-users"></i>
                    <h3>User Management</h3>
                    <p>Manage accounts, add, update, or delete users.</p>
                </div>

                <div class="task-card">
                    <i class="fas fa-file-alt"></i>
                    <h3>Monitor User </h3>
                    <p>View encryption/decryption logs.</p>
                </div>

                <div class="task-card">
                    <i class="fas fa-comments"></i>
                    <h3>Feedback</h3>
                    <p>Manage user feedback and queries.</p>
                </div>
                <div class="task-card">
                    <i class="fas fa-chart-line"></i>
                    <h3>Activity Monitoring</h3>
                    <p>Track user activities for insights.</p>
                </div>

                <div class="task-card">
                    <i class="fas fa-user"></i>
                    <h3>Profile</h3>
                    <p>Update your admin profile.</p>
                </div>

            </section>
        </main>
    </div>
</body>
</html>
