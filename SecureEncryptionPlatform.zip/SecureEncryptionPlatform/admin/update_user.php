<?php
include 'config.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $id = intval($_POST['id']);
    $name = mysqli_real_escape_string($conn, $_POST['name']);
    $username = mysqli_real_escape_string($conn, $_POST['username']);
    $email = mysqli_real_escape_string($conn, $_POST['email']);

    $checkUserQuery = "SELECT * FROM user WHERE (username='$username' OR email='$email') AND id != $id";
    $result = mysqli_query($conn, $checkUserQuery);

    if (mysqli_num_rows($result) > 0) {
        echo "<script>alert('Username or email already exists for another user!'); window.location.href='usermanagement.php';</script>";
    } else {
        $query = "UPDATE user SET name='$name', username='$username', email='$email' WHERE id=$id";
        if (mysqli_query($conn, $query)) {
            echo "<script>alert('User updated successfully!'); window.location.href='usermanagement.php';</script>";
        } else {
            echo "<script>alert('Error updating user!'); window.location.href='usermanagement.php';</script>";
        }
    }
}
?>
