
    <!-- Footer -->
    <div class="footer">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                  <div class="footer-col first">
              <h5>About CryptZone</h5>
              <p class="p-small">CryptZone is a robust platform designed to provide community-based encryption and decryption solutions, ensuring secure communication and data protection for all users.</p>
          </div> <!-- end of footer-col -->

          <div class="footer-col second">
            <h5>Contact Info</h5>
            <ul class="list-unstyled li-space-lg p-small">
                <li class="media">
                    <i class="fas fa-map-marker-alt"></i>
                    <div class="media-body">Jazan University, Jazan, Saudi Arabia</div>
                </li>
                <li class="media">
                    <i class="fas fa-envelope"></i>
                    <div class="media-body"><a href="#your-link">support@cryptzone.com</a></div>
                </li>
                <li class="media">
                    <i class="fas fa-phone-alt"></i>
                    <div class="media-body"><a href="#your-link">+966 555 123 456</a></div>
                </li>
            </ul>
        </div> <!-- end of footer-col -->

                    <div class="footer-col third">
                        <h5>Value Links</h5>
                        <ul class="list-unstyled li-space-lg p-small">
                            <li><a href="terms-conditions.php">Terms & Conditions</a></li>
                        </ul>
                    </div> <!-- end of footer-col -->

                    <div class="footer-col fifth">
                        <span class="fa-stack">
                              <a href="#">
                                <i class="fas fa-circle fa-stack-2x"></i>
                                <i class="fab fa-facebook-f fa-stack-1x"></i>
                            </a>
                        </span>
                        <span class="fa-stack">
                              <a href="#">
                                <i class="fas fa-circle fa-stack-2x"></i>
                                <i class="fab fa-twitter fa-stack-1x"></i>
                            </a>
                        </span>
                        <span class="fa-stack">
                            <a href="#">
                                <i class="fas fa-circle fa-stack-2x"></i>
                                <i class="fab fa-pinterest-p fa-stack-1x"></i>
                            </a>
                        </span>
                        <span class="fa-stack">
                              <a href="#">
                                <i class="fas fa-circle fa-stack-2x"></i>
                                <i class="fab fa-instagram fa-stack-1x"></i>
                            </a>
                        </span>
                    </div> <!-- end of footer-col -->
                </div> <!-- end of col -->
            </div> <!-- end of row -->
        </div> <!-- end of container -->
    </div> <!-- end of footer -->
    <!-- end of footer -->



    <!-- Scripts -->
    <script src="js/jquery.min.js"></script> <!-- jQuery for Bootstrap's JavaScript plugins -->
    <script src="js/popper.min.js"></script> <!-- Popper tooltip library for Bootstrap -->
    <script src="js/bootstrap.min.js"></script> <!-- Bootstrap framework -->
    <script src="js/jquery.easing.min.js"></script> <!-- jQuery Easing for smooth scrolling between anchors -->
    <script src="js/swiper.min.js"></script> <!-- Swiper for image and text sliders -->
    <script src="js/jquery.magnific-popup.js"></script> <!-- Magnific Popup for lightboxes -->
    <script src="js/validator.min.js"></script> <!-- Validator.js - Bootstrap plugin that validates forms -->
    <script src="js/scripts.js"></script> <!-- Custom scripts -->
</body>
</html>
