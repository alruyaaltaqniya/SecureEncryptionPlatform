
<?php
include 'config.php';
session_start();

// Check if user is logged in
if (!isset($_SESSION['userId'])) {
    header("Location: login.php");
    exit();
}

// Fetch the logged-in user's details
$userId = $_SESSION['userId'];
$query = "SELECT * FROM user WHERE id = ?";
$stmt = $conn->prepare($query);
$stmt->bind_param("i", $userId);
$stmt->execute();
$result = $stmt->get_result();
$user = $result->fetch_assoc();

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = $_POST['name'];
    $username = $_POST['username'];
    $email = $_POST['email'];
    $accountType = $_POST['accountType'];

    // Handle profile image upload
    $profileImagePath = $user['profile']; // Default to current profile image
    if (!empty($_FILES['profileImage']['name'])) {
        $targetDir = "../images/";
        $imageName = date('YmdHis') . "_" . basename($_FILES['profileImage']['name']); // Unique name
        $targetFile = $targetDir . $imageName;

        if (move_uploaded_file($_FILES['profileImage']['tmp_name'], $targetFile)) {
            $profileImagePath = $targetFile; // Update profile image path
        } else {
            $error = "Failed to upload image. Please try again.";
        }
    }

    // Update user details in the database
    $query = "UPDATE user SET name = ?, username = ?, email = ?, accountType = ?, profile = ? WHERE id = ?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("sssssi", $name, $username, $email, $accountType, $profileImagePath, $userId);
    if ($stmt->execute()) {
        $success = "Profile updated successfully!";
        // Refresh user data
        header("Location: Edit-Profile.php");
        exit();
    } else {
        $error = "Failed to update profile. Please try again.";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Profile - CryptZone</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            background-color: #f8f9fc;
            font-family: 'Arial', sans-serif;
        }

        .form-container {
            max-width: 1000px;
            margin: 50px auto;
            background: #ffffff;
            border-radius: 8px;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
            padding: 20px;
        }

        .form-container h1 {
            font-size: 24px;
            color: #007bff;
            text-align: center;
            margin-bottom: 20px;
        }

        .form-container .btn {
            width: 100%;
            margin-top: 15px;
            transition: all 0.3s ease;
        }

        .form-container .btn:hover {
            transform: scale(1.05);
            box-shadow: 0px 4px 10px rgba(0, 0, 0, 0.2);
        }
    </style>
</head>
<body>
<?php include "header.php"; ?>
<br><br><br>
<div class="form-container">
    <h1>Edit Profile</h1>

    <!-- Success and Error Messages -->
    <?php if (isset($success)) { ?>
        <div class="alert alert-success"><?php echo $success; ?></div>
    <?php } ?>
    <?php if (isset($error)) { ?>
        <div class="alert alert-danger"><?php echo $error; ?></div>
    <?php } ?>

    <!-- Edit Profile Form -->
    <form method="POST" enctype="multipart/form-data">
        <div class="mb-3">
            <label for="name" class="form-label">Name</label>
            <input type="text" class="form-control" id="name" name="name" value="<?php echo $user['name']; ?>" required>
        </div>
        <div class="mb-3">
            <label for="username" class="form-label">Username</label>
            <input type="text" class="form-control" id="username" name="username" value="<?php echo $user['username']; ?>" required>
        </div>
        <div class="mb-3">
            <label for="email" class="form-label">Email</label>
            <input type="email" class="form-control" id="email" name="email" value="<?php echo $user['email']; ?>" required>
        </div>
        <div class="mb-3">
            <label for="accountType" class="form-label">Account Type</label>
            <select class="form-control" id="accountType" name="accountType" required>
                <option value="Public" <?php echo $user['accountType'] === 'Public' ? 'selected' : ''; ?>>Public</option>
                <option value="Private" <?php echo $user['accountType'] === 'Private' ? 'selected' : ''; ?>>Private</option>
            </select>
        </div>
        <div class="mb-3">
            <label for="profileImage" class="form-label">Profile Image</label>
            <input type="file" class="form-control" id="profileImage" name="profileImage" accept="image/*">
            <?php if (!empty($user['profile'])) { ?>
                <img src="<?php echo $user['profile']; ?>" alt="Current Profile" class="img-thumbnail mt-3" style="max-width: 100px;">
            <?php } ?>
        </div>
        <button type="submit" class="btn btn-primary">Save Changes</button>
    </form>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>

<?php
include 'footer.php';
 ?>
