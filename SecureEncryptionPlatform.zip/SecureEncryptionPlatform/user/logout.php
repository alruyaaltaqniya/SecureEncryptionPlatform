<?php
session_start();
include '../config.php';

// Update the user's statusOnline to 'close'
if (isset($_SESSION['userId']) && $_SESSION['userType'] === 'user') {
    $userId = $_SESSION['userId'];
    $updateStatus = "UPDATE user SET statusOnline = 'close' WHERE id = ?";
    $stmt = $conn->prepare($updateStatus);
    $stmt->bind_param("i", $userId);
    $stmt->execute();
}

// Destroy the session and unset all session variables
session_destroy();
foreach ($_SESSION as $key => $value) {
    unset($_SESSION[$key]);
}

// Redirect to the home page
header("Location: ../index.php");
exit;
?>
