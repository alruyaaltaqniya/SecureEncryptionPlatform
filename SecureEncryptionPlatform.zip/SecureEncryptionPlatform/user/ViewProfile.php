
<?php
include 'config.php';
session_start();

// Check if user is logged in
if (!isset($_SESSION['userId'])) {
    header("Location: login.php");
    exit();
}

// Fetch the logged-in user's details
$userId = $_SESSION['userId'];
$query = "SELECT * FROM user WHERE id = ?";
$stmt = $conn->prepare($query);
$stmt->bind_param("i", $userId);
$stmt->execute();
$result = $stmt->get_result();
$user = $result->fetch_assoc();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>View Profile - CryptZone</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            background-color: #f8f9fc;
            font-family: 'Arial', sans-serif;
        }

        .profile-container {
            max-width: 1000px;
            margin: 50px auto;
            background: #ffffff;
            border-radius: 8px;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
            overflow: hidden;
        }

        .profile-header {
            background-color: #7db9b6;
            color: white;
            padding: 20px;
            text-align: center;
        }

        .profile-header img {
            width: 100px;
            height: 100px;
            border-radius: 50%;
            border: 3px solid #fff;
            margin-bottom: 10px;
        }

        .profile-header h2 {
            margin: 0;
            font-size: 24px;
        }

        .profile-details {
            padding: 20px;
        }

        .profile-details h5 {
            margin-bottom: 10px;
            color: #333;
        }

        .profile-details p {
            margin-bottom: 20px;
            color: #666;
        }

        .btn {
            display: block;
            width: 100%;
            margin: 10px 0;
            transition: all 0.3s ease-in-out;
        }

        .btn:hover {
            transform: scale(1.05);
            box-shadow: 0px 4px 10px rgba(0, 0, 0, 0.2);
        }

        .btn-edit {
            background-color: #5ea8a3;
            color: white;
            border: none;
        }

        .btn-edit:hover {
            background-color: #4d918e;
        }

        .btn-password {
            background-color: #ffcc80;
            color: white;
            border: none;
        }

        .btn-password:hover {
            background-color: #ffa726;
        }
    </style>
</head>
<body>
<?php include "header.php"; ?>
<br><br><br><br>
<div class="profile-container">
    <div class="profile-header">
        <img src="../images/<?php echo $user['profile']; ?>" alt="Profile Picture">
        <h2><?php echo $user['name']; ?></h2>
        <p>@<?php echo $user['username']; ?></p>
    </div>
    <div class="profile-details">
        <h5>Email</h5>
        <p><?php echo $user['email']; ?></p>

        <h5>Account Type</h5>
        <p><?php echo $user['accountType']; ?></p>

        <h5>Status</h5>
        <p><?php echo ucfirst($user['status']); ?></p>

        <h5>Online Status</h5>
        <p><?php echo ucfirst($user['statusOnline']); ?></p>

        <!-- Update Profile Button -->
        <a href="Edit-Profile.php" class="btn btn-edit">
            <i class="fas fa-edit"></i> Edit Profile
        </a>

        <!-- Change Password Button -->
        <a href="change_password.php" class="btn btn-password">
            <i class="fas fa-lock"></i> Change Password
        </a>
    </div>
</div>
<?php
include 'footer.php';
 ?>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
