<script type="text/javascript">

const userId = "<?php echo $selectedUserId; ?>"; // المستخدم المحدد
const messagesContainer = document.getElementById("messages");

// Function to fetch messages
function fetchMessages() {
    if (userId) {
        fetch(`fetchMessages.php?userId=${userId}`)
            .then(response => response.json())
            .then(data => {
                // Clear old messages
                messagesContainer.innerHTML = "";

                // Add new messages
                data.forEach(message => {
                    const messageDiv = document.createElement("div");
                    messageDiv.className = `message ${message.senderId == <?php echo $userId; ?> ? 'sent' : 'received'}`;
                    messageDiv.innerHTML = `
                        <div class="text">${message.messageText}</div>
                        <img src="${message.profile}" class="ss" alt="Profile Image">
                        <small>${message.dateTime}</small>
                    `;
                    messagesContainer.appendChild(messageDiv);
                });

                // Scroll to the latest messages
                messagesContainer.scrollTop = messagesContainer.scrollHeight;
            })
            .catch(error => console.error("Error fetching messages:", error));
    }
}


// تحديث الرسائل دوريًا
fetchMessages();
setInterval(fetchMessages, 5000); // تحديث كل 5 ثوانٍ

document.getElementById("messageForm").addEventListener("submit", function (e) {
    e.preventDefault();

    const messageText = document.getElementById("messageText").value;
    const encryptionType = document.getElementById("encryptionType").value;

    fetch("sendMessage.php", {
        method: "POST",
        headers: { "Content-Type": "application/x-www-form-urlencoded" },
        body: `messageText=${encodeURIComponent(messageText)}&encryptionType=${encodeURIComponent(encryptionType)}&receiverId=${userId}`
    })
        .then(response => {
            if (response.ok) {
                document.getElementById("messageText").value = ""; // تفريغ حقل الإدخال
                fetchMessages(); // تحديث الرسائل
            } else {
                alert("Failed to send message");
            }
        })
        .catch(error => console.error("Error sending message:", error));
});

    function markMessagesAsRead(senderId) {
        fetch('markMessagesAsRead.php', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({ senderId: senderId }),
        }).then(response => {
            if (!response.ok) {
                console.error('Failed to mark messages as read');
            }
        }).catch(error => {
            console.error('Error:', error);
        });
    }


</script>
