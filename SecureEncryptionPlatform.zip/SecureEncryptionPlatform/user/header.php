<!DOCTYPE html>
<html lang="en">
<head>
<?php
include "head.php";
// Count unread messages
include "config.php";


$query = "SELECT COUNT(*) as unreadCount FROM sendreceive WHERE receiverId = ? AND status = 'sent'";
$stmt = $conn->prepare($query);
$stmt->bind_param("i", $userId);
$stmt->execute();
$result = $stmt->get_result();
$row = $result->fetch_assoc();

$unreadCount = $row['unreadCount'] ?? 0; // Default to 0 if no unread messages
?>
</head>
<body data-spy="scroll" data-target=".fixed-top">





    <!-- Navigation -->
    <nav class="navbar navbar-expand-lg navbar-dark navbar-custom fixed-top">
        <div class="container">
            <!-- Text Logo - Use this if you don't have a graphic logo -->
            <!-- <a class="navbar-brand logo-text page-scroll" href="index.html">Sync</a> -->

            <!-- Image Logo -->
            <a class="navbar-brand " href="index.php">
              <img src="images/logo2.png" width="120" alt="alternative"></a>

            <!-- Mobile Menu Toggle Button -->
            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarsExampleDefault" aria-controls="navbarsExampleDefault" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-awesome fas fa-bars"></span>
                <span class="navbar-toggler-awesome fas fa-times"></span>
            </button>
            <!-- end of mobile menu toggle button -->

            <div class="collapse navbar-collapse" id="navbarsExampleDefault">
                <ul class="navbar-nav ml-auto">
                  <li class="nav-item">
                      <a class="nav-link page-scroll" href="index.php">HOME <span class="sr-only">(current)</span></a>
                  </li>
                  <li class="nav-item dropdown">
                <a class="nav-link dropdown-toggle page-scroll" id="navbarDropdown" role="button" aria-haspopup="true" aria-expanded="false">Message</a>
                <div class="dropdown-menu" aria-labelledby="navbarDropdown">
                    <a class="dropdown-item" href="Encrypt.php"><span class="item-text">Encrypt Message</span></a>
                    <div class="dropdown-divider"></div>
                    <a class="dropdown-item" href="Decrypt.php"><span class="item-text">Decrypt Message</span></a>
                    <div class="dropdown-divider"></div>
                    <a class="dropdown-item" href="Chat.php">
                        <span class="item-text">Chat</span>
                        <?php if ($unreadCount > 0): ?>
                            <span class="badge bg-danger"><?php echo $unreadCount; ?></span>
                        <?php endif; ?>
                    </a>
                </div>
            </li>

									<li class="nav-item dropdown">
											<a class="nav-link dropdown-toggle page-scroll" id="navbarDropdown" role="button" aria-haspopup="true" aria-expanded="false">Profile</a>
											<div class="dropdown-menu" aria-labelledby="navbarDropdown">
													<a class="dropdown-item" href="ViewProfile.php"><span class="item-text">View Profile</span></a>
													<div class="dropdown-divider"></div>
													<a class="dropdown-item" href="Edit-Profile.php"><span class="item-text">Edit Profile</span></a>
													<div class="dropdown-divider"></div>
													<a class="dropdown-item" href="Shared-Accounts.php"><span class="item-text">Shared Accounts</span></a>
											</div>
									</li>

                    <li class="nav-item">
                        <a class="nav-link page-scroll" href="SendFeedback.php">SendFeedback </a>
                    </li>
										<li class="nav-item">
												<a class="nav-link page-scroll" href="Activity.php">Activity Log </a>
										</li>

                </ul>
             <span class="nav-item">
                    <a class="btn-outline-sm page-scroll" href="logout.php">logout</a>
                </span>

            </div>
        </div> <!-- end of container -->
    </nav> <!-- end of navbar -->
    <!-- end of navigation -->
