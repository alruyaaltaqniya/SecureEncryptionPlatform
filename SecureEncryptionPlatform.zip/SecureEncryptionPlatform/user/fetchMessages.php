<?php
include "config.php";
session_start();

if (!isset($_SESSION['userId']) || !isset($_GET['userId'])) {
    http_response_code(400);
    exit("Invalid Request");
}

$senderId = $_SESSION['userId'];
$receiverId = intval($_GET['userId']);

// Fetch messages along with profile images
$query = "
    SELECT sr.id, sr.senderId, sr.receiverId, sr.messageText, sr.dateTime,
           u.profile
    FROM sendreceive sr
    JOIN user u ON sr.senderId = u.id
    WHERE (sr.senderId = ? AND sr.receiverId = ?)
       OR (sr.senderId = ? AND sr.receiverId = ?)
    ORDER BY sr.dateTime ASC";

$stmt = $conn->prepare($query);
$stmt->bind_param("iiii", $senderId, $receiverId, $receiverId, $senderId);

if ($stmt->execute()) {
    $result = $stmt->get_result();
    $messages = [];

    while ($row = $result->fetch_assoc()) {
        $messages[] = $row;
    }

    header("Content-Type: application/json");
    echo json_encode($messages);
} else {
    http_response_code(500);
    echo "Failed to fetch messages.";
}
?>
