<?php
include "config.php";
session_start();

// Check if user is logged in
if (!isset($_SESSION['userId'])) {
    header("Location: login.php");
    exit();
}

$error = '';
$success = '';
$encryptedText = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $userId = $_SESSION['userId'];
    $text = trim($_POST['text']);
    $encryptionType = $_POST['encryptionType'];

    if (empty($text) || empty($encryptionType)) {
        $error = "All fields are required.";
    } else {
        // Perform encryption based on selected type
        switch ($encryptionType) {
            case 'AES':
                $encryptedText = base64_encode(openssl_encrypt($text, 'AES-128-CTR', 'encryptionkey', 0, '1234567891011121'));
                break;
            case 'RSA':
            $publicKeyPath = 'keys/public_key.pem'; // Replace with the path to your public_key.pem file
               $publicKey = file_get_contents($publicKeyPath);

               if (!$publicKey) {
                   $error = "Failed to load the RSA public key.";
                   break;
               }

               // Encrypt the message using the public key
               if (!openssl_public_encrypt($text, $encryptedOutput, $publicKey)) {
                   $error = "Failed to encrypt message with RSA.";
                   break;
               }

               // Base64 encode the encrypted message
               $encryptedText = base64_encode($encryptedOutput);
            break;

            case 'Base64':
                $encryptedText = base64_encode($text);
                break;
            default:
                $error = "Invalid encryption type.";
        }

        // Save encrypted text to database
        if (empty($error)) {
            $stmt = $conn->prepare("INSERT INTO encrypt (userId, text, encryptiontype) VALUES (?, ?, ?)");
            $stmt->bind_param("iss", $userId, $encryptedText, $encryptionType);
            if ($stmt->execute()) {
                $success = "Message encrypted successfully!";
            } else {
                $error = "Failed to save encrypted message.";
            }
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Encrypt Message - CryptZone</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            background-color: #f8f9fc;
            font-family: 'Arial', sans-serif;
        }

        .container {
            max-width: 800px;
            margin: 50px auto;
            background: #fff;
            border-radius: 8px;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
            padding: 20px;
        }

        .btn {
            transition: all 0.3s ease;
        }

        .btn:hover {
            transform: scale(1.05);
        }

        .copy-btn {
            margin-right: 10px;
        }
    </style>
</head>
<body>
<?php include "header.php"; ?>
<br><br>
<br><br>
<br><br>

<div class="container">
    <h1 class="text-center mb-4">Encrypt Message</h1>

    <!-- Success and Error Messages -->
    <?php if ($success): ?>
        <div class="alert alert-success"><?php echo $success; ?></div>
    <?php elseif ($error): ?>
        <div class="alert alert-danger"><?php echo $error; ?></div>
    <?php endif; ?>

    <!-- Encryption Form -->
    <form method="POST">
        <div class="mb-3">
            <label for="text" class="form-label">Message to Encrypt</label>
            <textarea class="form-control" id="text" name="text" rows="3" required></textarea>
        </div>
        <div class="mb-3">
            <label for="encryptionType" class="form-label">Encryption Type</label>
            <select class="form-select" id="encryptionType" name="encryptionType" required>
                <option value="" disabled selected>Select Encryption Type</option>
                <option value="AES">AES</option>
                <option value="RSA">RSA</option>
                <option value="Base64">Base64</option>
            </select>
        </div>
        <button type="submit" class="btn btn-primary">Encrypt</button>
    </form>

    <?php if ($encryptedText): ?>
        <hr>
        <h3>Encrypted Message</h3>
        <div class="mb-3">
            <textarea class="form-control" id="encryptedMessage" rows="3" readonly><?php echo $encryptedText; ?></textarea>
        </div>
        <button class="btn btn-secondary copy-btn" onclick="copyToClipboard()">Copy</button>
        <button class="btn btn-success" onclick="shareToWhatsApp()">Share to WhatsApp</button>
    <?php endif; ?>
</div>

<script>
    function copyToClipboard() {
        const textArea = document.getElementById('encryptedMessage');
        textArea.select();
        textArea.setSelectionRange(0, 99999); // For mobile devices
        navigator.clipboard.writeText(textArea.value)
            .then(() => {
                alert('Copied to clipboard!');
            })
            .catch(err => {
                alert('Failed to copy: ', err);
            });
    }

    function shareToWhatsApp() {
        const encryptedText = document.getElementById('encryptedMessage').value;
        const phoneNumber = prompt("Enter the phone number (with country code):", "+");
        if (phoneNumber) {
            const whatsappURL = `https://wa.me/${phoneNumber.replace('+', '')}?text=${encodeURIComponent(encryptedText)}`;
            window.open(whatsappURL, '_blank');
        }
    }
</script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
