<?php include "head12.php" ?>
<?php

$query = "
    SELECT
        u.id AS userId,
        u.username,
        u.profile,
        u.statusOnline,
        (SELECT COUNT(*) FROM sendreceive WHERE senderId = u.id AND receiverId = ? AND status = 'sent') AS unreadCount,
        (SELECT COUNT(*) FROM sendreceive WHERE (senderId = u.id AND receiverId = ?) OR (senderId = ? AND receiverId = u.id)) AS totalMessages
    FROM user u
    WHERE u.id != ?
";
$stmt = $conn->prepare($query);
$stmt->bind_param("iiii", $userId, $userId, $userId, $userId);
$stmt->execute();
$allUsers = $stmt->get_result();
?>

<?php if ($success): ?>
    <div class="alert alert-success"><?php echo $success; ?></div>
<?php elseif ($error): ?>
    <div class="alert alert-danger"><?php echo $error; ?></div>
<?php endif; ?>

<br><br><br><br>
<div class="container mt-4">
    <div class="chat-container">
      <!-- User List -->
      <div class="user-list">
          <ul>
              <?php if ($allUsers->num_rows > 0) {
                  while ($user = $allUsers->fetch_assoc()) { ?>
                      <a href="Chat.php?userId=<?php echo $user['userId']; ?>"
                         onclick="markMessagesAsRead(<?php echo $user['userId']; ?>)">
                          <li class="<?php echo $selectedUserId == $user['userId'] ? 'active' : ''; ?>">
                              <img src="<?php echo $user['profile']; ?>" class="ss" alt="Profile Image">
                              <strong><?php echo $user['username']; ?></strong>
                              <small class="sss">
                                  <?php echo $user['statusOnline'] === 'online' ? 'Online' : 'Offline'; ?>
                              </small>
                              
                              <?php if ($user['unreadCount'] > 0): ?>
                                  <span class="badge bg-danger"> <?php echo $user['unreadCount']; ?></span>
                              <?php endif; ?>
                          </li>
                      </a>
              <?php }
              } else { ?>
                  <li>No users found.</li>
              <?php } ?>
          </ul>
      </div>





        <!-- Chat Area -->
        <div class="chat-area">
            <div class="chat-header">
                <h4>
                    <?php
                    if ($selectedUserId) {
                        $usernameQuery = "SELECT username FROM user WHERE id = ?";
                        $stmt = $conn->prepare($usernameQuery);
                        $stmt->bind_param("i", $selectedUserId);
                        $stmt->execute();
                        $result = $stmt->get_result();
                        $selectedUser = $result->fetch_assoc();
                        echo "Chat with " . $selectedUser['username'];
                    } else {
                        echo "Select a user to start chatting";
                    }
                    ?>
                </h4>
            </div>


  <div class="messages" id="messages">
    <?php if ($selectedUserId && $messages->num_rows > 0) {
        while ($message = $messages->fetch_assoc()) { ?>
            <div class="message <?php echo $message['senderId'] == $userId ? 'sent' : 'received'; ?>">
                  <img src="<?php echo $message['profile']; ?>" class="ss" alt="Profile Image">
                <div class="text">
                    <?php echo htmlspecialchars($message['messageText']); ?>
                </div>
                <small><?php echo $message['dateTime']; ?></small>
            </div>
    <?php }
    } elseif ($selectedUserId) {
        echo "<p class='no-chat'>No messages yet. Start the conversation!</p>";
    } else {
        echo "<p class='no-chat'>Select a user to start chatting</p>";
    } ?>
</div>

<?php if ($selectedUserId) { ?>
    <form method="POST" id="messageForm" class="message-input">
        <select name="encryptionType" id="encryptionType" class="form-select form-select-sm">
            <option value="None" selected>None</option>
            <option value="AES">AES</option>
            <option value="Base64">Base64</option>
        </select>
        <input type="text" name="messageText" id="messageText" class="form-control" placeholder="Type your message" required>
        <button type="submit" class="btn btn-primary">Send</button>
    </form>
<?php } ?>

        </div>
    </div>
</div>
<?php include "dd.php"; ?>
<?php include "footer.php"; ?>
