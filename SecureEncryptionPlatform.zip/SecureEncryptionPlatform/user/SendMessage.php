<?php
include "config.php";
session_start();

if (!isset($_SESSION['userId']) || !isset($_POST['messageText']) || !isset($_POST['encryptionType']) || !isset($_POST['receiverId'])) {
    http_response_code(400);
    exit("Invalid Request");
}

$senderId = $_SESSION['userId'];
$receiverId = intval($_POST['receiverId']);
$messageText = $_POST['messageText'];
$encryptionType = $_POST['encryptionType'];

// Apply encryption based on the selected type
$encryptedMessage = $messageText; // Default to plain text
$encryptedText = null; // To store encryption specifically for the encrypt table

if ($encryptionType === 'AES') {
    $encryptedMessage = base64_encode(openssl_encrypt($messageText, 'AES-128-CTR', 'encryptionkey', 0, '1234567891011121'));
    $encryptedText = $encryptedMessage;
} elseif ($encryptionType === 'Base64') {
    $encryptedMessage = base64_encode($messageText);
    $encryptedText = $encryptedMessage;
}

// Insert the encrypted message into the `encrypt` table
if ($encryptionType !== 'None' && $encryptedText !== null) {
    $stmt1 = $conn->prepare("INSERT INTO encrypt (userId, text, encryptiontype) VALUES (?, ?, ?)");
    if ($stmt1) {
        $stmt1->bind_param("iss", $senderId, $encryptedText, $encryptionType);
        if (!$stmt1->execute()) {
            http_response_code(500);
            exit("Failed to save encrypted message: " . $stmt1->error);
        }
        $stmt1->close();
    } else {
        http_response_code(500);
        exit("Failed to prepare encrypt table statement: " . $conn->error);
    }
}

// Insert the message into the `sendreceive` table
$insertMessageQuery = "
    INSERT INTO sendreceive (senderId, receiverId, messageText, status)
    VALUES (?, ?, ?, 'sent')";
$stmt = $conn->prepare($insertMessageQuery);
if ($stmt) {
    $stmt->bind_param("iis", $senderId, $receiverId, $encryptedMessage);
    if ($stmt->execute()) {
        http_response_code(200);
        exit("Message Sent");
    } else {
        http_response_code(500);
        exit("Failed to send message: " . $stmt->error);
    }
    $stmt->close();
} else {
    http_response_code(500);
    exit("Failed to prepare sendreceive table statement: " . $conn->error);
}
?>
