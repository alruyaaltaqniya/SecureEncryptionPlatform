<?php
include "config.php";
session_start();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $data = json_decode(file_get_contents('php://input'), true);
    $senderId = $data['senderId'] ?? 0;
    $receiverId = $_SESSION['userId'];

    if ($senderId && $receiverId) {
        $updateQuery = "UPDATE sendreceive SET status = 'read' WHERE senderId = ? AND receiverId = ? AND status = 'sent'";
        $stmt = $conn->prepare($updateQuery);
        $stmt->bind_param("ii", $senderId, $receiverId);
        $stmt->execute();
        http_response_code(200);
        exit("Messages marked as read");
    }
}

http_response_code(400);
exit("Invalid Request");
?>
