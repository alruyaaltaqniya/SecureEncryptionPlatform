<?php
include "config.php";
session_start();
$error = '';
$success = '';

// التحقق من تسجيل الدخول
if (!isset($_SESSION['userId'])) {
    header("Location: login.php");
    exit();
}

$userId = $_SESSION['userId'];

// جلب الحسابات المشتركة
function fetchSharedAccounts($conn, $userId) {
    $query = "
        SELECT sa.username, sa.userId, u.statusOnline, u.profile,
               (SELECT MAX(dateTime) FROM activitylog WHERE userId = sa.userId) AS lastLogin
        FROM shareaccount sa
        JOIN user u ON sa.userId = u.id
        WHERE sa.status = 'Accept' AND sa.userId = ?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("i", $userId);
    $stmt->execute();
    return $stmt->get_result();
}

// جلب كل المستخدمين مع آخر تسجيل دخول
function fetchAllUsers($conn) {
    $query = "
        SELECT u.id, u.username, u.profile, u.statusOnline,
               (SELECT MAX(dateTime) FROM activitylog WHERE userId = u.id) AS lastLogin
        FROM user u";
    $stmt = $conn->prepare($query);
    $stmt->execute();
    return $stmt->get_result();
}

// جلب الرسائل مع مستخدم محدد
function fetchMessages($conn, $userId, $selectedUserId) {
    $query = "
        SELECT sr.*, u.username AS senderUsername
        FROM sendreceive sr
        JOIN user u ON sr.senderId = u.id
        WHERE (sr.senderId = ? AND sr.receiverId = ?)
           OR (sr.senderId = ? AND sr.receiverId = ?)
        ORDER BY sr.dateTime ASC";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("iiii", $userId, $selectedUserId, $selectedUserId, $userId);
    $stmt->execute();
    return $stmt->get_result();
}
// Function to handle message sending

function sendMessage($conn, $userId, $selectedUserId, $messageText, $encryptionType)
{
    $encryptedMessage = $messageText; // Default is plain text
    $encryptedText = null; // Variable to store the encrypted message for the `encrypt` table

    // Apply encryption based on the selected type
    if ($encryptionType === 'AES') {
        $encryptedMessage = base64_encode(openssl_encrypt($messageText, 'AES-128-CTR', 'encryptionkey', 0, '1234567891011121'));
        $encryptedText = $encryptedMessage;
    } elseif ($encryptionType === 'Base64') {
        $encryptedMessage = base64_encode($messageText);
        $encryptedText = $encryptedMessage;
    } elseif ($encryptionType === 'None') {
        $encryptedText = $messageText; // Save plain text in the `encrypt` table
    }


  if ($encryptionType !== 'None') {
    $insertEncryptQuery = "INSERT INTO encrypt (userId, text, encryptiontype) VALUES (?, ?, ?)";
    $stmt = $conn->prepare($insertEncryptQuery);
    if ($stmt) {
        $stmt->bind_param("iss", $userId, $encryptedMessage, $encryptionType);
        if (!$stmt->execute()) {
            die("Error inserting into sendreceive table: " . $stmt->error);
        }
        $stmt->close();
    } else {
        die("Error preparing statement for sendreceive table: " . $conn->error);
      }
    }

    // Save the message (encrypted or plain) into the `sendreceive` table
    $insertMessageQuery = "INSERT INTO sendreceive (senderId, receiverId, messageText, status) VALUES (?, ?, ?, 'sent')";
    $stmt = $conn->prepare($insertMessageQuery);
    if ($stmt) {
        $stmt->bind_param("iis", $userId, $selectedUserId, $encryptedMessage);
        if (!$stmt->execute()) {
            die("Error inserting into sendreceive table: " . $stmt->error);
        }
        $stmt->close();
    } else {
        die("Error preparing statement for sendreceive table: " . $conn->error);
    }
}






?>
