
<?php
include 'config.php';
session_start();

// Check if user is logged in
if (!isset($_SESSION['userId'])) {
    header("Location: login.php");
    exit();
}

$userId = $_SESSION['userId'];

// Handle feedback submission
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['feedbackText'])) {
    $feedbackText = htmlspecialchars($_POST['feedbackText'], ENT_QUOTES, 'UTF-8');

    $query = "INSERT INTO feedback (userId, feedbackText, state) VALUES (?, ?, 'unread')";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("is", $userId, $feedbackText);

    if ($stmt->execute()) {
        $success = "Your feedback has been sent successfully!";
    } else {
        $error = "Failed to send feedback. Please try again.";
    }
}

// Fetch feedback sent by admin to the logged-in user
$query = "SELECT feedbackText, feedbackDate, state FROM feedback WHERE userId = ? ORDER BY feedbackDate DESC";
$stmt = $conn->prepare($query);
$stmt->bind_param("i", $userId);
$stmt->execute();
$result = $stmt->get_result();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Send Feedback - CryptZone</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            background-color: #f8f9fc;
            font-family: 'Arial', sans-serif;
        }

        .feedback-container {
            max-width: 1100px;
            margin: 50px auto;
            background: #ffffff;
            border-radius: 8px;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
            padding: 20px;
        }

        .feedback-container h1 {
            font-size: 24px;
            color: #007bff;
            text-align: center;
            margin-bottom: 20px;
        }

        .feedback-list {
            max-height: 400px;
            overflow-y: auto;
        }

        .feedback-item {
            background: #f8f9fc;
            border: 1px solid #ddd;
            border-radius: 5px;
            margin-bottom: 15px;
            padding: 10px 15px;
            transition: box-shadow 0.3s ease;
        }

        .feedback-item:hover {
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.15);
        }

        .feedback-date {
            font-size: 12px;
            color: #777;
        }

        .feedback-status {
            font-size: 12px;
            color: #007bff;
            font-weight: bold;
        }

        .btn-submit-feedback {
            background: #007bff;
            color: #fff;
            transition: all 0.3s ease;
        }

        .btn-submit-feedback:hover {
            transform: scale(1.05);
            box-shadow: 0px 4px 10px rgba(0, 0, 0, 0.2);
        }
    </style>
</head>
<body>
<?php include "header.php"; ?>
<br><br><br>
<div class="feedback-container">
    <h1>Send Feedback</h1>

    <!-- Success and Error Messages -->
    <?php if (isset($success)) { ?>
        <div class="alert alert-success"><?php echo $success; ?></div>
    <?php } ?>
    <?php if (isset($error)) { ?>
        <div class="alert alert-danger"><?php echo $error; ?></div>
    <?php } ?>

    <!-- Feedback Form -->
    <form method="POST" class="mb-4">
        <div class="mb-3">
            <label for="feedbackText" class="form-label">Your Feedback</label>
            <textarea class="form-control" id="feedbackText" name="feedbackText" rows="3" placeholder="Write your feedback here..." required></textarea>
        </div>
        <button type="submit" class="btn btn-submit-feedback btn-success btn-block">Send Feedback</button>
    </form>

    <!-- Feedback List -->
    <h2 class="mb-3">Feedback from Admin</h2>
    <div class="feedback-list">
        <?php while ($feedback = $result->fetch_assoc()) { ?>
            <div class="feedback-item">
                <p><?php echo $feedback['feedbackText']; ?></p>
                <div class="d-flex justify-content-between">
                    <span class="feedback-date"><?php echo date('F j, Y, g:i a', strtotime($feedback['feedbackDate'])); ?></span>
                    <span class="feedback-status"><?php echo ucfirst($feedback['state']); ?></span>
                </div>
            </div>
        <?php } ?>
        <?php if ($result->num_rows === 0) { ?>
            <p class="text-center text-muted">No feedback received yet.</p>
        <?php } ?>
    </div>
</div>
<?php include "footer.php" ?>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
