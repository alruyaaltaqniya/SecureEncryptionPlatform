<?php
session_start();
include '../config.php';

// Check if the user is logged in
if (!isset($_SESSION['userId']) || $_SESSION['userType'] !== 'user') {
    header("Location: ../login.php");
    exit();
}

// Fetch user activity logs
$userId = $_SESSION['userId'];
$limit = 10; // Number of records to display per page
$offset = isset($_GET['offset']) ? intval($_GET['offset']) : 0;

// Fetch last 10 login records
$query = "SELECT * FROM activitylog WHERE userId = ? ORDER BY dateTime DESC LIMIT ?, ?";
$stmt = $conn->prepare($query);
$stmt->bind_param("iii", $userId, $offset, $limit);
$stmt->execute();
$result = $stmt->get_result();

// Total records count for pagination
$countQuery = "SELECT COUNT(*) as total FROM activitylog WHERE userId = ?";
$countStmt = $conn->prepare($countQuery);
$countStmt->bind_param("i", $userId);
$countStmt->execute();
$countResult = $countStmt->get_result();
$totalRecords = $countResult->fetch_assoc()['total'];
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Activity Log - CryptZone</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/js/bootstrap.bundle.min.js"></script>
    <style>
        body {
            font-family: 'Roboto', sans-serif;
            background-color: #f3f4f6;
            color: #333;
            margin: 0;
            padding: 0;
        }

        .container {
            margin-top: 30px;
            padding: 20px;
        }

        .activity-log {
            max-width: 900px;
            margin: 0 auto;
        }

        .card {
            border: none;
            border-radius: 10px;
            box-shadow: 0px 2px 10px rgba(0, 0, 0, 0.1);
            background-color: #ffffff;
        }

        .card-header {
            background-color: #0d6efd;
            color: #000;
            font-size: 1.5rem;
            font-weight: bold;
            padding: 15px 20px;
            border-radius: 10px 10px 0 0;
            text-align: center;
        }

        .card-body {
            padding: 20px;
            font-size: 1rem;
            line-height: 1.6;
            color: #495057;
        }

        .list-group-item {
            border: none;
            padding: 15px;
            background-color: #f8f9fa;
            margin-bottom: 5px;
            border-radius: 5px;
            color: #212529;
        }

        .list-group-item:hover {
            background-color: #e9ecef;
        }

        .search-bar {
            margin-bottom: 20px;
            display: flex;
            gap: 10px;
            justify-content: center;
            align-items: center;
        }

        .search-input {
            flex: 1;
            padding: 10px 15px;
            border: 1px solid #ced4da;
            border-radius: 5px;
            font-size: 1rem;
        }

        .search-btn {
            background-color: #0d6efd;
            color: #ffffff;
            border: none;
            padding: 10px 20px;
            border-radius: 5px;
            cursor: pointer;
            font-size: 1rem;
            transition: background-color 0.3s ease;
        }

        .search-btn:hover {
            background-color: #0a58ca;
        }

        .no-activity {
            text-align: center;
            color: #6c757d;
            font-size: 1rem;
            margin-top: 10px;
        }

        .load-more-btn {
            display: block;
            margin: 20px auto;
            padding: 10px 20px;
            background-color: #0d6efd;
            color: #ffffff;
            border: none;
            border-radius: 5px;
            text-align: center;
            text-decoration: none;
            cursor: pointer;
            font-size: 1rem;
            transition: background-color 0.3s ease, transform 0.3s ease;
        }

        .load-more-btn:hover {
            background-color: #0a58ca;
            transform: scale(1.05);
        }

        footer {
            margin-top: 50px;
            background-color: #f1f3f5;
            padding: 20px;
            text-align: center;
            font-size: 0.9rem;
            color: #6c757d;
        }
    </style>

</head>
<body>
    <?php include 'header.php'; ?>
    <br><br><br><br>
    <br><br><br><br>

    <div class="container activity-log">
        <div class="search-bar">
            <form method="GET" action="">
                <input type="date" name="searchDate" class="search-input" value="<?php echo isset($_GET['searchDate']) ? $_GET['searchDate'] : ''; ?>" required>
                <button type="submit" class="search-btn">Search</button>
            </form>
        </div>

        <div class="card">
            <div class="card-header">Activity Log</div>
            <div class="card-body">
                <?php
                if (isset($_GET['searchDate'])) {
                    $searchDate = $_GET['searchDate'];
                    $searchQuery = "SELECT * FROM activitylog WHERE userId = ? AND DATE(dateTime) = ? ORDER BY dateTime DESC";
                    $searchStmt = $conn->prepare($searchQuery);
                    $searchStmt->bind_param("is", $userId, $searchDate);
                    $searchStmt->execute();
                    $searchResult = $searchStmt->get_result();

                    if ($searchResult->num_rows > 0) {
                        echo "<ul class='list-group'>";
                        while ($log = $searchResult->fetch_assoc()) {
                            echo "<li class='list-group-item'>Login on " . date("d M Y, h:i A", strtotime($log['dateTime'])) . "</li>";
                        }
                        echo "</ul>";
                    } else {
                        echo "<p class='no-activity'>No activity found for the selected date.</p>";
                    }
                } else {
                    if ($result->num_rows > 0) {
                        echo "<ul class='list-group'>";
                        while ($log = $result->fetch_assoc()) {
                            echo "<li class='list-group-item'>Login on " . date("d M Y, h:i A", strtotime($log['dateTime'])) . "</li>";
                        }
                        echo "</ul>";
                    } else {
                        echo "<p class='no-activity'>No activity logs available.</p>";
                    }
                }
                ?>
            </div>
        </div>

        <?php if (!isset($_GET['searchDate']) && $offset + $limit < $totalRecords) { ?>
            <a href="?offset=<?php echo $offset + $limit; ?>" class="load-more-btn">Load More</a>
        <?php } ?>
    </div>

    <?php include "footer.php"; ?>
</body>
</html>
