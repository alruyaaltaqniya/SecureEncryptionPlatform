<?php
include "chatFunctions.php";

$sharedAccounts = fetchSharedAccounts($conn, $userId);
$allUsers = fetchAllUsers($conn);

$selectedUserId = isset($_GET['userId']) ? intval($_GET['userId']) : 0;
$messages = [];
if ($selectedUserId) {
    $messages = fetchMessages($conn, $userId, $selectedUserId);
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['messageText'], $_POST['encryptionType'])) {
    sendMessage($conn, $userId, $selectedUserId, $_POST['messageText'], $_POST['encryptionType']);
    header("Location: Chat.php?userId=$selectedUserId");
    exit();
}
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Chat - CryptZone</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <link rel="stylesheet" href="chatstyle.css">
    <link rel="stylesheet" href="ss.css">

</head>
<body>
<?php include "header.php"; ?>
