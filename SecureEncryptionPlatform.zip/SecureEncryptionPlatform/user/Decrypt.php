<?php
include "config.php";
session_start();

// Check if user is logged in
if (!isset($_SESSION['userId'])) {
    header("Location: login.php");
    exit();
}

$userId = $_SESSION['userId'];

// Fetch encrypted messages for the logged-in user
$encryptedMessagesQuery = "SELECT * FROM encrypt WHERE userId = ?";
$stmt = $conn->prepare($encryptedMessagesQuery);
$stmt->bind_param("i", $userId);
$stmt->execute();
$encryptedMessages = $stmt->get_result();

// Fetch decrypted messages for the logged-in user
$decryptedMessagesQuery = "SELECT * FROM decrypt WHERE userId = ?";
$stmt = $conn->prepare($decryptedMessagesQuery);
$stmt->bind_param("i", $userId);
$stmt->execute();
$decryptedMessages = $stmt->get_result();

$error = '';
$decryptedText = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $encryptionType = $_POST['encryptionType'];
    $encryptedText = $_POST['encryptedText'];

    if (empty($encryptionType) || empty($encryptedText)) {
        $error = "All fields are required.";
    } else {
        // Perform decryption based on the selected type
        switch ($encryptionType) {
            case 'AES':
                $decryptedText = openssl_decrypt(base64_decode($encryptedText), 'AES-128-CTR', 'encryptionkey', 0, '1234567891011121');
                break;
            case 'RSA':
            $privateKeyPath = 'keys/private_key.pem'; // Replace with the path to your private_key.pem file
    $privateKey = file_get_contents($privateKeyPath);

    if (!$privateKey) {
        $error = "Failed to load the RSA private key.";
        break;
    }

    // Decrypt the message using the private key
    $privateKeyResource = openssl_pkey_get_private($privateKey);
    if (!$privateKeyResource) {
        $error = "Failed to parse the RSA private key.";
        break;
    }

    if (!openssl_private_decrypt(base64_decode($encryptedText), $decryptedText, $privateKeyResource)) {
        $error = "Failed to decrypt message with RSA.";
        break;
    }
                break;
            case 'Base64':
                $decryptedText = base64_decode($encryptedText);
                break;
            default:
                $error = "Invalid decryption type.";
        }

        // Save decrypted message to the database
        if ($decryptedText && empty($error)) {
            $stmt = $conn->prepare("INSERT INTO decrypt (userId, text, decrptionType) VALUES (?, ?, ?)");
            $stmt->bind_param("iss", $userId, $decryptedText, $encryptionType);
            $stmt->execute();
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Decrypt Message - CryptZone</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>


        .container {
            max-width: 1000px;
            margin: 50px auto;
            background: #ffffff;
            border-radius: 8px;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
            padding: 20px;
        }

        .btn {
            transition: all 0.3s ease;
        }

        .btn:hover {
            transform: scale(1.05);
        }

        .decrypted-message {
            margin-top: 20px;
            padding: 15px;
            background-color: #d4edda;
            color: #155724;
            border: 1px solid #c3e6cb;
            border-radius: 8px;
        }
    </style>
</head>
<body>
<?php include "header.php"; ?>
<br><br>
<br><br>
<br><br>

<div class="container">
    <h1 class="text-center mb-4">Decrypt Messages</h1>

    <!-- Display error messages -->
    <?php if ($error): ?>
        <div class="alert alert-danger"><?php echo $error; ?></div>
    <?php endif; ?>

    <!-- Table to display encrypted messages -->
    <h2 class="mb-3">Your Encrypted Messages</h2>
    <table class="table table-striped table-hover">
        <thead>
            <tr>
                <th>#</th>
                <th>Encrypted Message</th>
                <th>Date/Time</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php while ($row = $encryptedMessages->fetch_assoc()) { ?>
            <tr>
                <td><?php echo $row['encryptId']; ?></td>
                <td class="encrypted-message">
                    <?php echo htmlspecialchars($row['text']); ?>
                </td>

                <td><?php echo $row['dateTime']; ?></td>
                <td>
                    <form method="POST" style="display:inline;">
                        <input type="hidden" name="encryptedText" value="<?php echo $row['text']; ?>">
                        <input type="text" name="encryptionType" value=""class=" form-select-sm mb-2"><br>
                        <!--<select class="form-select form-select-sm mb-2" name="encryptionType" required>
                            <option value="" disabled selected>Choose Type</option>
                            <option value="AES">AES</option>
                            <option value="RSA">RSA</option>
                            <option value="Base64">Base64</option>
                        </select>-->
                        <button type="submit" class="btn btn-success btn-sm">Decrypt</button>
                    </form>
                    <a href="delete_message.php?id=<?php echo $row['encryptId']; ?>" class="btn btn-danger btn-sm">Delete</a>
                </td>
            </tr>
            <?php } ?>
        </tbody>
    </table>

    <script>
        function showFullMessage(message) {
            alert("Encrypted Message:\n" + message);
        }
    </script>
    <style>
    .encrypted-message {
        white-space: pre-wrap; /* Allow wrapping */
        word-break: break-all; /* Break long words */
        max-width: 400px; /* Set a maximum width */
        overflow: hidden; /* Hide overflow content */
        text-overflow: ellipsis; /* Add ellipsis for long content */
    }
</style>
    <div class="feedback-container">
    <h2 class="mb-3"> Decrypt Messages</h2>

<form method="POST"  class="mb-4">
    <div class="mb-3">
      <label for="feedbackText" class="form-label">encrypted Text</label>
    <textarea type="text" name="encryptedText"class="form-control" ></textarea>
      </div>
        <div class="mb-3">
          <label for="feedbackText" class="form-label">encryption Type</label>
    <textarea type="text" name="encryptionType" value="" class="form-control"></textarea>
      </div>
    <!--<select class="form-select form-select-sm mb-2" name="encryptionType" required>
        <option value="" disabled selected>Choose Type</option>
        <option value="AES">AES</option>
        <option value="RSA">RSA</option>
        <option value="Base64">Base64</option>
    </select>-->
    <button type="submit" class="btn btn-success btn-sm">Decrypt</button>
</form>
</div>

    <!-- Table to display decrypted messages -->
    <h2 class="mb-3">Your Decrypted Messages</h2>
    <table class="table table-striped table-hover">
        <thead>
            <tr>
                <th>#</th>
                <th>Decrypted Message</th>
                <th>Date/Time</th>
            </tr>
        </thead>
        <tbody>
            <?php while ($row = $decryptedMessages->fetch_assoc()) { ?>
            <tr>
                <td><?php echo $row['decryptId']; ?></td>
                <td><?php echo $row['text']; ?></td>
                <td><?php echo $row['dateTime']; ?></td>
            </tr>
            <?php } ?>
        </tbody>
    </table>


    <!-- Display decrypted message -->
    <?php if ($decryptedText): ?>
        <div class="decrypted-message">
            <h4>Decrypted Message:</h4>
            <p><?php echo $decryptedText; ?></p>
        </div>
    <?php endif; ?>
</div>
<?php include "footer.php"; ?>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
