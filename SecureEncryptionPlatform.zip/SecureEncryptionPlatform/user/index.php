<?php include "header.php" ?>

    <!-- Header -->
    <header class="header">
        <div class="container">
            <div class="row">
                <div class="col-lg-6">
                    <div class="text-container">
                        <h3>Secure Community-Based Encryption and Decryption Platform </h3>
                      <p class="p-large p-heading">The project's goal is to create a safe online community where members may utilize different encryption algorithms to encrypt and decrypt private text conversations. Through the platform, users may establish a safe shared account where they can trade data without risk. It is possible for User A to establish a shared account and ask other users to sign up. The sender encrypts the text in the platform and distributes it across any communication channel when sending sensitive material. In order to decode the communication, the receiver then logs onto the platform.</p>

                    </div> <!-- end of text-container -->
                </div> <!-- end of col -->

                <div class="col-lg-6">
                    <div class="image-container">
                        <img class="img-fluid" src="images/header-iphone.png" alt="alternative">
                    </div> <!-- end of text-container -->
                </div> <!-- end of col -->
              </div> <!-- end of col -->

        </div> <!-- end of container -->
        <div class="deco-white-circle-1">
            <img src="images/decorative-white-circle.svg" alt="alternative">
        </div> <!-- end of deco-white-circle-1 -->
        <div class="deco-white-circle-2">
            <img src="images/decorative-white-circle.svg" alt="alternative">
        </div> <!-- end of deco-white-circle-2 -->
        <div class="deco-blue-circle">
            <img src="images/decorative-blue-circle.svg" alt="alternative">
        </div> <!-- end of deco-blue-circle -->
        <div class="deco-yellow-circle">
            <img src="images/decorative-yellow-circle.svg" alt="alternative">
        </div> <!-- end of deco-yellow-circle -->
        <div class="deco-green-diamond">
            <img src="images/decorative-green-diamond.svg" alt="alternative">
        </div> <!-- end of deco-yellow-circle -->
    </header> <!-- end of header -->
    <!-- end of header -->


    <!-- Small Features -->
    <div class="cards-1">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">

                    <!-- Card -->
                    <div class="card">
                        <div class="card-image">
                            <i class="fas fa-users"></i>
                        </div>
                        <div class="card-body">
                            <h5 class="card-title">Set Security Goals</h5>
                        </div>
                    </div>
                    <!-- end of card -->

                    <!-- Card -->
                    <div class="card">
                        <div class="card-image green">
                            <i class="fas fa-code"></i>
                        </div>
                        <div class="card-body">
                            <h5 class="card-title">Analyze Threats</h5>
                        </div>
                    </div>
                    <!-- end of card -->

                    <!-- Card -->
                    <div class="card">
                        <div class="card-image red">
                            <i class="fas fa-cog"></i>
                        </div>
                        <div class="card-body">
                            <h5 class="card-title">Define Tasks</h5>
                        </div>
                    </div>
                    <!-- end of card -->

                    <!-- Card -->
                    <div class="card">
                        <div class="card-image yellow">
                            <i class="fas fa-comments"></i>
                        </div>
                        <div class="card-body">
                            <h5 class="card-title">Enable Collaboration</h5>
                        </div>
                    </div>
                    <!-- end of card -->

                    <!-- Card -->
                    <div class="card">
                        <div class="card-image blue">
                            <i class="fas fa-rocket"></i>
                        </div>
                        <div class="card-body">
                            <h5 class="card-title">Secure Communications</h5>
                        </div>
                    </div>
                    <!-- end of card -->

                </div> <!-- end of col -->
            </div> <!-- end of row -->
        </div> <!-- end of container -->
    </div> <!-- end of cards-1 -->
    <!-- end of small features -->


    <!-- Description 1 -->
    <div id="description" class="basic-1">
        <div class="container">
            <div class="row">
                <div class="col-lg-6">
                    <div class="image-container">
                        <img class="img-fluid" src="images/description-1-app.png" alt="alternative">
                    </div> <!-- end of image-container -->
                </div> <!-- end of col -->
                <div class="col-lg-6">
                    <div class="text-container">
                      <h2>Secure Your Communication with Ease</h2>
        <p>Our platform empowers communities with advanced encryption tools to safeguard your messages and foster secure interactions. Experience seamless communication while prioritizing privacy.</p>
        <ul class="list-unstyled li-space-lg">
            <li class="media">
                <i class="fas fa-square"></i>
                <div class="media-body">Identify your community's security needs and goals</div>
            </li>
            <li class="media">
                <i class="fas fa-square"></i>
                <div class="media-body">Utilize encryption to protect sensitive messages and data</div>
            </li>
            <li class="media">
                <i class="fas fa-square"></i>
                <div class="media-body">Enhance collaboration with secure shared accounts</div>
            </li>
            <li class="media">
                <i class="fas fa-square"></i>
                <div class="media-body">Monitor activity and receive feedback to ensure transparency</div>
            </li>
        </ul>
                        <a class="btn-solid-reg popup-with-move-anim" href="#description-1-details-lightbox">LIGHTBOX</a>
                    </div> <!-- end of text-container -->
                </div> <!-- end of col -->
            </div> <!-- end of row -->
        </div> <!-- end of container -->
    </div> <!-- end of basic-1 -->
    <!-- end of description 1 -->


    <!-- Description 1 Details Lightbox -->
	<!-- Details Lightbox -->
	<div id="description-1-details-lightbox" class="lightbox-basic zoom-anim-dialog mfp-hide">
        <div class="row">
            <button title="Close (Esc)" type="button" class="mfp-close x-button">×</button>
			<div class="col-lg-8">
                <div class="image-container">
                    <img class="img-fluid" src="images/description-1-details-lightbox.jpg" alt="alternative">
                </div> <!-- end of image-container -->
			</div>
			<div class="col-lg-4">
        <h3>Encryption and Decryption</h3>
      <hr>
      <p>Our platform ensures secure communication within your community by leveraging advanced encryption and decryption techniques. Protect your data and collaborate securely.</p>
      <h4>User Benefits</h4>
      <p>With our platform, you can communicate safely, protect sensitive information, and manage feedback, all in one secure system.</p>
      <ul class="list-unstyled li-space-lg">
          <li class="media">
              <i class="far fa-check-square"></i><div class="media-body">Secure user login with two-factor authentication</div>
          </li>
          <li class="media">
              <i class="far fa-check-square"></i><div class="media-body">Encrypted messaging for privacy</div>
          </li>
          <li class="media">
              <i class="far fa-check-square"></i><div class="media-body">User-friendly message decryption interface</div>
          </li>
          <li class="media">
              <i class="far fa-check-square"></i><div class="media-body">Activity monitoring for transparency</div>
          </li>
          <li class="media">
              <i class="far fa-check-square"></i><div class="media-body">Feedback system to enhance user experience</div>
          </li>
      </ul>
                <a class="btn-solid-reg mfp-close page-scroll" href="login.php">login</a>

                 <button class="btn-outline-reg mfp-close as-button" type="button">BACK</button>
			</div>
		</div> <!-- end of row -->
    </div> <!-- end of lightbox-basic -->
    <!-- end of details lightbox -->
    <!-- end of description 1 details lightbox -->





    <!-- Features -->
    <div id="features" class="basic-2">
        <div class="container">
          <div class="row">
    <div class="col-lg-12">
        <h2>Special Features</h2>
        <p class="p-heading">CryptZone's features are designed to provide a secure and seamless communication experience. Encrypt your messages, manage shared accounts, and ensure your data stays protected while collaborating with your community.</p>
    </div> <!-- end of div -->
</div> <!-- end of div -->

            <div class="row">
                <div class="col-lg-4">
                    <ul class="list-unstyled li-space-lg first">
                        <li class="media">
                            <span class="fa-stack">
                                <i class="fas fa-circle fa-stack-2x"></i>
                                <i class="fas fa-users fa-stack-1x"></i>
                            </span>
                            <div class="media-body">
        <h4>Data Security</h4>
        <p>Everything begins with prioritizing the security of your data and ensuring safe communication within your community.</p>
    </div>

                        </li>
                        <li class="media">
                            <span class="fa-stack">
                                <i class="fas fa-circle fa-stack-2x green"></i>
                                <i class="fas fa-code fa-stack-1x"></i>
                            </span>
                            <div class="media-body">
        <h4>Situation Analysis</h4>
        <p>CryptZone offers advanced tools to assess security needs, ensuring your communications and data remain fully protected.</p>
    </div>

                        </li>
                        <li class="media">
                            <span class="fa-stack">
                                <i class="fas fa-circle fa-stack-2x red"></i>
                                <i class="fas fa-cog fa-stack-1x"></i>
                            </span>
                            <div class="media-body">
            <h4>Tasks Settings</h4>
            <p>Every feature in CryptZone is designed to streamline encryption and decryption tasks, ensuring secure and efficient communication.</p>
        </div>

                        </li>
                    </ul>
                </div> <!-- end of col -->
                <div class="col-lg-4">
                    <img class="img-fluid" src="images/features-app.jpg" alt="alternative">
                </div> <!-- end of col -->
                <div class="col-lg-4">
                    <ul class="list-unstyled li-space-lg">
                        <li class="media">
                            <span class="fa-stack">
                                <i class="fas fa-circle fa-stack-2x yellow"></i>
                                <i class="fas fa-comments fa-stack-1x"></i>
                            </span>
                            <div class="media-body">
        <h4>Social Interaction</h4>
        <p>Enhance secure collaboration within your community by exchanging encrypted messages and managing shared accounts effortlessly.</p>
    </div>

                        </li>
                        <li class="media">
                            <span class="fa-stack">
                                <i class="fas fa-circle fa-stack-2x blue"></i>
                                <i class="fas fa-rocket fa-stack-1x"></i>
                            </span>
                            <div class="media-body">
          <h4>Get Things Done</h4>
          <p>Securely encrypt, decrypt, and manage messages with ease, enabling your community to focus on achieving goals without compromising privacy.</p>
      </div>

                        </li>
                        <li class="media">
                            <span class="fa-stack">
                                <i class="fas fa-circle fa-stack-2x"></i>
                                <i class="fas fa-download fa-stack-1x"></i>
                            </span>
                            <div class="media-body">
          <h4>Good Foundation</h4>
          <p>Build a solid foundation for secure communication and data protection. Start using CryptZone to safeguard your community today.</p>
      </div>

                        </li>
                    </ul>
                </div> <!-- end of col -->
            </div> <!-- end of row -->
        </div> <!-- end of container -->
    </div> <!-- end of basic-2 -->
