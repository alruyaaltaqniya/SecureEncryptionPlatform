<?php
include 'config.php';
session_start();

// Check if the user is logged in
if (!isset($_SESSION['userId'])) {
    header("Location: login.php");
    exit();
}

// Logged-in user information
$loggedInUserId = $_SESSION['userId'];
$loggedInUsername = $_SESSION['username'];

// Handle account sharing
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['shareWith'])) {
    $shareWith = trim($_POST['shareWith']);

    // Check if the user exists
    $query = "SELECT id, username, accountType FROM user WHERE username = ?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("s", $shareWith);
    $stmt->execute();
    $result = $stmt->get_result();
    $user = $result->fetch_assoc();

    if ($user) {
        if ($user['id'] == $loggedInUserId) {
            $error = "You cannot share your account with yourself.";
        } else {
            // Check if already shared
            $checkQuery = "SELECT * FROM shareaccount WHERE username = ? AND userId = ? AND sharedfrom = ?";
            $checkStmt = $conn->prepare($checkQuery);
            $checkStmt->bind_param("sii", $shareWith, $loggedInUserId, $loggedInUserId);
            $checkStmt->execute();
            $existingShare = $checkStmt->get_result();

            if ($existingShare->num_rows > 0) {
                $error = "This account is already shared.";
            } else {
                // Insert into shareaccount table
                $query = "INSERT INTO shareaccount (username, userId, status, sharedfrom) VALUES (?, ?, 'Ignore', ?)";
                $stmt = $conn->prepare($query);
                $stmt->bind_param("sii", $shareWith, $loggedInUserId, $loggedInUserId);
                if ($stmt->execute()) {
                    $success = "Account shared successfully!";
                } else {
                    $error = "Failed to share account. Try again.";
                }
            }
        }
    } else {
        $error = "User does not exist.";
    }
}

// Handle accept/reject shared accounts
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && isset($_POST['shareId'])) {
    $action = $_POST['action'];
    $shareId = $_POST['shareId'];

    $query = "UPDATE shareaccount SET status = ? WHERE shareId = ? AND username = ?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("sis", $action, $shareId, $loggedInUsername);
    if ($stmt->execute()) {
        $success = "Account updated successfully!";
    } else {
        $error = "Failed to update the account.";
    }
}
// Handle deletion of shared accounts
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['deleteSharedAccount'])) {
    $shareIdToDelete = $_POST['shareIdToDelete'];

    $deleteQuery = "DELETE FROM shareaccount WHERE shareId = ? AND sharedfrom = ?";
    $stmt = $conn->prepare($deleteQuery);
    $stmt->bind_param("ii", $shareIdToDelete, $loggedInUserId);
    if ($stmt->execute()) {
        $success = "Shared account deleted successfully!";
    } else {
        $error = "Failed to delete the shared account.";
    }
}
// Fetch accounts shared by the logged-in user
$querySharedByMe = "
    SELECT sa.*, u.name AS sharedWithName, u.profile AS sharedWithProfile, u.statusOnline
    FROM shareaccount sa
    JOIN user u ON sa.username = u.username
    WHERE sa.sharedfrom = ?
";
$stmt = $conn->prepare($querySharedByMe);
$stmt->bind_param("i", $loggedInUserId);
$stmt->execute();
$sharedByMe = $stmt->get_result();
// Fetch all public accounts
$query = "SELECT * FROM user WHERE accountType = 'Public'";
$publicAccounts = $conn->query($query);

// Fetch shared accounts
$query = "SELECT sa.*, u.name AS sharedFromName
          FROM shareaccount sa
          JOIN user u ON sa.sharedfrom = u.id
          WHERE sa.username = ?";
$stmt = $conn->prepare($query);
$stmt->bind_param("s", $loggedInUsername);
$stmt->execute();
$sharedAccounts = $stmt->get_result();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Shared Accounts - CryptZone</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        .card-container {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
            gap: 20px;
            margin-top: 20px;
        }

        .card {
            border: 1px solid #ddd;
            border-radius: 8px;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
            transition: transform 0.3s, box-shadow 0.3s;
        }

        .card:hover {
            transform: scale(1.05);
            box-shadow: 0 8px 20px rgba(0, 0, 0, 0.15);
        }

        .card img {
            max-height: 150px;
            object-fit: cover;
            border-bottom: 1px solid #ddd;
        }

        .card-title {
            font-size: 20px;
            margin: 10px 0;
        }

        .btn {
            margin-top: 10px;
        }
    </style>
</head>
<body>
<?php include "header.php"; ?>
<br><br>
<div class="container mt-5">


    <!-- Messages -->
    <?php if (isset($success)) { ?>
        <div class="alert alert-success"><?php echo $success; ?></div>
    <?php } ?>
    <?php if (isset($error)) { ?>
        <div class="alert alert-danger"><?php echo $error; ?></div>
    <?php } ?>

    <!-- Public Accounts -->
    <h2 class="mt-4">Public Accounts</h2>
    <div class="card-container">
        <?php while ($row = $publicAccounts->fetch_assoc()) { ?>
            <div class="card">
                <img src="../images/<?php echo $row['profile']; ?>" alt="Profile Image" class="card-img-top">
                <div class="card-body">
                    <h5 class="card-title"><?php echo $row['name']; ?></h5>
                    <p class="card-text">Username: <?php echo $row['username']; ?></p>
                    <p class="card-text" style="color: <?php echo $row['statusOnline'] == 'online' ? 'green' : 'red'; ?>">
                        <?php echo $row['statusOnline']; ?>
                    </p>
                </div>
            </div>
        <?php } ?>
    </div>

    <!-- Accounts Shared By Me -->
    <h2 class="mt-4">Accounts Shared By Me</h2>
    <div class="card-container">
        <?php while ($row = $sharedByMe->fetch_assoc()) { ?>
            <div class="card">
                <img src="../images/<?php echo $row['sharedWithProfile']; ?>" alt="Profile Image" class="card-img-top">
                <div class="card-body">
                    <h5 class="card-title"><?php echo $row['sharedWithName']; ?></h5>
                    <p class="card-text">Status: <?php echo $row['status']; ?></p>
                    <p class="card-text" style="color: <?php echo $row['statusOnline'] === 'online' ? 'green' : 'red'; ?>">
                        <?php echo $row['statusOnline'] === 'online' ? 'Online' : 'Offline'; ?>
                    </p>
                    <!-- Delete Button -->
                    <button class="btn btn-danger btn-sm" onclick="confirmDelete(<?php echo $row['shareId']; ?>, '<?php echo $row['sharedWithName']; ?>')">
                        Delete
                    </button>
                </div>
            </div>
        <?php } ?>
    </div>


    <!-- Share Account Form -->
    <h2 class="mt-5">Friend Requests</h2>
    <form method="POST">
        <div class="mb-3">
            <label for="shareWith" class="form-label">Share Account With</label>
            <input type="text" class="form-control" id="shareWith" name="shareWith" placeholder="Enter username" required>
        </div>
        <button type="submit" class="btn btn-primary">Share Account</button>
    </form>

    <!-- Shared Accounts Table -->
    <h2 class="mt-5">Shared Accounts</h2>
    <table id="userTable" class="table table-striped table-hover" >
        <thead>
        <tr>
            <th>#</th>
            <th>Shared From</th>
            <th>Shared By</th>
            <th>Date/Time</th>
            <th>Status</th>
            <th>Actions</th>
        </tr>
        </thead>
        <tbody>
        <?php while ($row = $sharedAccounts->fetch_assoc()) { ?>
            <tr>
                <td><?php echo $row['shareId']; ?></td>
                <td><?php echo $row['sharedFromName']; ?></td>
                <td><?php echo $row['userId'] == $loggedInUserId ? "You" : $row['userId']; ?></td>
                <td><?php echo $row['datetime']; ?></td>
                <td><?php echo $row['status']; ?></td>
                <td>
                    <form method="POST" class="d-inline">
                        <input type="hidden" name="shareId" value="<?php echo $row['shareId']; ?>">
                        <button type="submit" name="action" value="Accept" class="btn btn-success btn-sm">Accept</button>
                        <button type="submit" name="action" value="Reject" class="btn btn-danger btn-sm">Reject</button>
                    </form>
                </td>
            </tr>
        <?php } ?>
        </tbody>
    </table>
</div>
<?php include "footer.php" ?>

<!-- JavaScript for Delete Confirmation -->
<script>
    function confirmDelete(shareId, sharedWithName) {
        const confirmModal = `
            <div class="modal fade" id="deleteConfirmModal" tabindex="-1" aria-labelledby="deleteConfirmModalLabel" aria-hidden="true">
                <div class="modal-dialog">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h5 class="modal-title" id="deleteConfirmModalLabel">Confirm Deletion</h5>
                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                        </div>
                        <div class="modal-body">
                            Are you sure you want to delete the shared account for <strong>${sharedWithName}</strong>?
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                            <button type="button" class="btn btn-danger" onclick="deleteSharedAccount(${shareId})">Delete</button>
                        </div>
                    </div>
                </div>
            </div>
        `;

        // Append modal to the body
        document.body.insertAdjacentHTML('beforeend', confirmModal);

        // Show the modal
        const modal = new bootstrap.Modal(document.getElementById('deleteConfirmModal'));
        modal.show();

        // Remove the modal after it's hidden
        document.getElementById('deleteConfirmModal').addEventListener('hidden.bs.modal', function () {
            document.getElementById('deleteConfirmModal').remove();
        });
    }

    function deleteSharedAccount(shareId) {
        // Send a POST request to delete the shared account
        fetch('delete_shared_account.php', {
            method: 'POST',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            body: `shareId=${shareId}`
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                alert('Shared account deleted successfully!');
                location.reload(); // Reload the page to reflect changes
            } else {
                alert('Failed to delete the shared account.');
            }
        })
        .catch(error => console.error('Error:', error));
    }
</script>
<script>
    $(document).ready(function() {
        $('#userTable').DataTable();
    });

    function deleteUser(id) {
        if (confirm('Are you sure you want to delete this user?')) {
            window.location.href = `delete_user.php?id=${id}`;
        }
    }

    function makeActive(id) {
        if (confirm('Are you sure you want to make this user active?')) {
            window.location.href = `make_active.php?id=${id}`;
        }
    }
</script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
