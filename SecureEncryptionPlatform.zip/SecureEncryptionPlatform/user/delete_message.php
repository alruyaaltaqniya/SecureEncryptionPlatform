<?php
include "config.php";
session_start();

// Check if user is logged in
if (!isset($_SESSION['userId'])) {
    header("Location: login.php");
    exit();
}

if (isset($_GET['id'])) {
    $encryptId = intval($_GET['id']);

    // Delete the message
    $stmt = $conn->prepare("DELETE FROM encrypt WHERE encryptId = ?");
    $stmt->bind_param("i", $encryptId);
    $stmt->execute();
}

header("Location: Decrypt.php");
exit();
?>
