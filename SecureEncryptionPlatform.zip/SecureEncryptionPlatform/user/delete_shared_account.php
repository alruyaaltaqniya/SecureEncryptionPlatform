<?php
include 'config.php';
session_start();

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['shareId'])) {
    $shareId = intval($_POST['shareId']);
    $loggedInUserId = $_SESSION['userId'];

    // Check if the shared account belongs to the logged-in user
    $query = "DELETE FROM shareaccount WHERE shareId = ? AND sharedfrom = ?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("ii", $shareId, $loggedInUserId);

    if ($stmt->execute()) {
        echo json_encode(['success' => true]);
    } else {
        echo json_encode(['success' => false]);
    }
    exit();
}
?>
